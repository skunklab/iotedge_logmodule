The following Orleans NuGet packages have been deprecated since version 1.2.0:
Microsoft.Orleans.Templates.Grains and Microsoft.Orleans.Templates.Interfaces

You should use Microsoft.Orleans.OrleansCodeGenerator.Build NuGet package instead (usable for both grain interfaces and implementation projects).
It is safe to remove the deprecated packages if it was not done automatically.