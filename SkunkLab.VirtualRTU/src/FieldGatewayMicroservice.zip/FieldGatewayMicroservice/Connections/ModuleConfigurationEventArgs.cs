﻿using System;
using VirtualRtu.Common.Configuration;

namespace FieldGatewayMicroservice.Connections
{
    public class ModuleConfigurationEventArgs : EventArgs
    {
        public ModuleConfigurationEventArgs(IssuedConfig config)
        {
            Config = config;   
        }

        public IssuedConfig Config { get; internal set; }
    }
}
