﻿using System;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace LogModule
{
    public class ContainerRemote : IContainerRemote
    {
        public static ContainerRemote Create(string accountName, string accountKey)
        {
            if(instance == null)
            {
                instance = new ContainerRemote(accountName, accountKey);
            }

            return instance;
        }

        protected ContainerRemote(string accountName, string accountKey)
        {
            operations = CommonIO.Create(accountName, accountKey);
        }

        protected CommonIO operations;
        private static ContainerRemote instance;

        public async Task DownloadFile(string path, string filename, string blobPath, string blobFilename, bool append = false)
        {
            if (string.IsNullOrEmpty(path))
            {
                throw new ArgumentNullException("path");
            }

            if (string.IsNullOrEmpty(filename))
            {
                throw new ArgumentNullException("filename");
            }

            if (string.IsNullOrEmpty(blobPath))
            {
                throw new ArgumentNullException("blobPath");
            }

            if (string.IsNullOrEmpty(blobFilename))
            {
                throw new ArgumentNullException("blobFilename");
            }

            try
            {
                string fileToWrite = operations.FixPath(path) + filename;
                string container = operations.GetContainerName(blobPath);
                string fileToRead = operations.GetFilenameForContainer(blobPath, blobFilename);
                byte[] blob = await operations.ReadBlockBlobAsync(container, fileToRead);

                if (append)
                {
                    await operations.WriteAppendFileAsync(fileToWrite, blob);
                }
                else
                {
                    await operations.WriteFileAsync(fileToWrite, blob);
                }
            }
            catch (Exception ex)
            {
                operations.LogToDocker("DownloadFile", ex);
                throw ex;
            }
        }

        public async Task DownloadFile(string path, string filename, string sasUri, bool append = false)
        {
            if (string.IsNullOrEmpty(path))
            {
                throw new ArgumentNullException("path");
            }

            if (string.IsNullOrEmpty(filename))
            {
                throw new ArgumentNullException("filename");
            }

            if (string.IsNullOrEmpty(sasUri))
            {
                throw new ArgumentNullException("sasUri");
            }

            try
            {
                string fileToWrite = operations.FixPath(path) + filename;
                byte[] blob = await operations.ReadBlockBlobAsync(sasUri);

                if (append)
                {
                    await operations.WriteAppendFileAsync(fileToWrite, blob);
                }
                else
                {
                    await operations.WriteFileAsync(fileToWrite, blob);
                }
            }
            catch (Exception ex)
            {
                operations.LogToDocker("DownloadFile", ex);
                throw ex;
            }
        }

        public async Task UploadFile(string path, string filename, string blobPath, string blobFilename, string contentType, bool append = false)
        {
            if (string.IsNullOrEmpty(path))
            {
                throw new ArgumentNullException("path");
            }

            if (string.IsNullOrEmpty(filename))
            {
                throw new ArgumentNullException("filename");
            }

            if (string.IsNullOrEmpty(blobPath))
            {
                throw new ArgumentNullException("blobPath");
            }

            if (string.IsNullOrEmpty(blobFilename))
            {
                throw new ArgumentNullException("blobFilename");
            }

            if (string.IsNullOrEmpty(contentType))
            {
                throw new ArgumentNullException("contentType");
            }

            try
            {
                string fileToRead = operations.FixPath(path) + filename;
                string container = operations.GetContainerName(blobPath);
                string fileToWrite = operations.GetFilenameForContainer(blobPath, blobFilename);

                byte[] source = await operations.ReadFileAsync(fileToRead);
                if (source != null)
                {
                    if (append)
                    {
                        string crlf = "\r\n";
                        byte[] crlfBytes = Encoding.UTF8.GetBytes(crlf);
                        byte[] buffer = new byte[crlfBytes.Length + source.Length];
                        Buffer.BlockCopy(crlfBytes, 0, buffer, 0, crlfBytes.Length);
                        Buffer.BlockCopy(source, 0, buffer, crlfBytes.Length, source.Length);
                        await operations.WriteAppendBlobAsync(container, fileToWrite, buffer, contentType);
                    }
                    else
                    {
                        await operations.WriteBlockBlobAsync(container, fileToWrite, source, contentType);
                    }
                }
            }
            catch (Exception ex)
            {
                operations.LogToDocker("UploadFile", ex);
                throw ex;
            }
        }

        public async Task UploadFile(string path, string filename, string sasUri, string contentType, bool append = false)
        {
            if (string.IsNullOrEmpty(path))
            {
                throw new ArgumentNullException("path");
            }

            if (string.IsNullOrEmpty(filename))
            {
                throw new ArgumentNullException("filename");
            }

            if (string.IsNullOrEmpty(sasUri))
            {
                throw new ArgumentNullException("sasUri");
            }

            if (string.IsNullOrEmpty(contentType))
            {
                throw new ArgumentNullException("contentType");
            }

            try
            {
                string fileToRead = operations.FixPath(path) + filename;
                byte[] source = await operations.ReadFileAsync(fileToRead);
                if (source != null)
                {
                    if (append)
                    {
                        string crlf = "\r\n";
                        byte[] crlfBytes = Encoding.UTF8.GetBytes(crlf);
                        byte[] buffer = new byte[crlfBytes.Length + source.Length];
                        Buffer.BlockCopy(crlfBytes, 0, buffer, 0, crlfBytes.Length);
                        Buffer.BlockCopy(source, 0, buffer, crlfBytes.Length, source.Length);
                        await operations.WriteAppendBlobAsync(sasUri, buffer, contentType);
                    }
                    else
                    {
                        await operations.WriteBlockBlobAsync(sasUri, source, contentType);
                    }
                }
            }
            catch (Exception ex)
            {
                operations.LogToDocker("UploadFile", ex);
                throw ex;
            }
        }

        public async Task TruncateFile(string path, string filename, int maxBytes)
        {
            if (string.IsNullOrEmpty(path))
            {
                throw new ArgumentNullException("sourcePath");
            }

            if (string.IsNullOrEmpty(filename))
            {
                throw new ArgumentNullException("sourceFilename");
            }

            if (maxBytes < 0)
            {
                throw new ArgumentOutOfRangeException("maxBytes");
            }

            try
            {
                string srcFilename = operations.FixPath(path) + filename;
                byte[] content = await operations.ReadFileAsync(srcFilename);

                if (content.Length > maxBytes)
                {
                    byte[] buffer = new byte[maxBytes];
                    Buffer.BlockCopy(content, content.Length - maxBytes, buffer, 0, maxBytes);
                    await operations.WriteFileAsync(srcFilename, buffer);
                }
            }
            catch (Exception ex)
            {
                operations.LogToDocker("TruncateFile", ex);
                throw ex;
            }
        }

        public async Task RemoveFile(string path, string filename)
        {
            try
            {
                string srcPath = operations.FixPath(path);
                string srcFilename = srcPath + filename;
                if (File.Exists(srcFilename))
                {
                    await operations.DeleteFileAsync(srcFilename);
                }
            }
            catch (Exception ex)
            {
                operations.LogToDocker("RemoveFile", ex);
                throw ex;
            }
        }

        public async Task CompressFile(string path, string filename, string compressPath, string compressFilename)
        {
            if(string.IsNullOrEmpty(path))
            {
                throw new ArgumentNullException("path");
            }

            if(string.IsNullOrEmpty(filename))
            {
                throw new ArgumentNullException("filename");
            }

            if(string.IsNullOrEmpty(compressPath))
            {
                throw new ArgumentNullException("compressPath");
            }

            if(string.IsNullOrEmpty(compressFilename))
            {
                throw new ArgumentNullException("compressFilename");
            }

            try
            {
                await operations.CompressFileAsync(path, filename, compressPath, compressFilename);
            }
            catch(Exception ex)
            {
                operations.LogToDocker("CompressFile", ex);
                throw ex;
            }
        }

        
    }
}
