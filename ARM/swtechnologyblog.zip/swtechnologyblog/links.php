<?php
/*
Template Name: Links
*/
?>

<?php get_header(); ?>
<div class="main_body">
	<?php get_sidebar(); ?>
	<div class="main_content">	
						<!-- content start -->	
<div id="content" class="widecolumn">

<h2>Links:</h2>
<ul>
<?php get_links_list(); ?>
</ul>

</div>
<!-- content end -->	

		</div>
</div>
<?php get_footer(); ?>
