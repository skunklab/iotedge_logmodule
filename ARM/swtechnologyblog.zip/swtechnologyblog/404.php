<?php get_header(); ?>
<div class="main_body">
	<?php get_sidebar(); ?>
	<div class="main_content">	
						<!-- content start -->	
	<div id="content" class="narrowcolumn">

		<h2 class="center">Error 404 - Not Found</h2>

	</div>

<!-- content end -->	

		</div>
</div>

<?php get_footer(); ?>