<div id="txt_logo"><a href="<?php echo get_option('home'); ?>" class="txt_logo_link"> <?php bloginfo('name'); ?> </a></div>
<div class="desc"><?php bloginfo('description');?></div>