<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<title><?php bloginfo('name'); ?> <?php if ( is_single() ) { ?> &raquo; Blog Archive <?php } ?> <?php wp_title(); ?></title>
<meta name="generator" content="WordPress <?php bloginfo('version'); ?>" /> <!-- leave this for stats -->
<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<link href="<?php echo bloginfo('stylesheet_directory'); ?>/style.css" rel="stylesheet" type="text/css" />

</head>
<body>
<div align="center">
	<div class="container">
		<div class="main_header">
			<div class="header_title">
					<? include(TEMPLATEPATH."/title.php"); ?>
			</div>
			<div class="mainpix_header">
				<div class="mainpix01"></div>
				<div class="mainpix02"></div>
			</div>
			<div class="header_menu">
				<div id="nav">					
					<div class="menu">
					<ul>
						<li class="page_item<?php if (is_home()) echo ' current_page_item'; ?>"><a href="<?php echo get_option('home'); ?>/">Home</a></li>
						<?php wp_list_pages('title_li=' ); ?>
					</ul>
					</div>				
				</div>
			</div>
		</div>