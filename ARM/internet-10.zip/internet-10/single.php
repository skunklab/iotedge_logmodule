<?php get_header(); ?>

		<div class="left">
        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			<div class="left_articles">

				
				<h2 class="title"><a id="post-<?php the_ID(); ?>" href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title(); ?>""><?php the_title(); ?></a></h2>
				<p class="description">Autor <?php the_author() ?> <?php edit_post_link('Edit',' | ',''); ?></p>
				<?php the_content(''); ?>
			</div>
		<?php comments_template(); ?>
		<?php endwhile; ?>

		
		<?php else : ?>
			<h2>Not Found</h2>
			<p>Sorry, but you are looking for something that isn't here.</p>
			<?php include (TEMPLATEPATH . "/searchform.php"); ?>
		<?php endif; ?>
		</div>	
		
		<div id="right">
			<div class="boxtop"></div>
			<div class="box">
					<h2>Options</h2>
					<ul class="contentright">
					<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
					<li>
						<span class="datea">
						<img src="<?php bloginfo('stylesheet_directory'); ?>/images/timeicon.gif" alt="" align="absmiddle" />
						</span> 
						<?php the_time('F j, Y') ?>
					</li>
					<li>
						<span class="datea">
						<img src="<?php bloginfo('stylesheet_directory'); ?>/images/folder.gif" alt="" align="absmiddle" />
						</span>
						<?php the_category(', ') ?>
					</li>
					<li>
						<span class="datea">
						<img src="<?php bloginfo('stylesheet_directory'); ?>/images/comment.gif" alt="" align="absmiddle" />
						</span>
						<a href="#comments"><?php comments_number('0 comments','1 comment','% comments');?></a>
					</li>
					<li>
						<span class="datea">
						<img src="<?php bloginfo('stylesheet_directory'); ?>/images/rss.gif" alt="" align="absmiddle" />
						</span>
						<?php comments_rss_link('Comments RSS'); ?>
					</li>



					<li>
						<span class="datea">
						<img src="<?php bloginfo('stylesheet_directory'); ?>/images/delicious.gif" alt="" align="absmiddle" />
						</span>
						<a href="http://del.icio.us/post?url=<?php the_permalink() ?>&title=<?php the_title(); ?> ">Del.ico.us</a>
					</li>


					<li>
						<span class="datea">
						<img src="<?php bloginfo('stylesheet_directory'); ?>/images/digg.gif" alt="" align="absmiddle" />
						</span>
						<a href="http://www.digg.com/submit?phase=2&url=<?php the_permalink(); ?>&title=<?php echo(the_title()); ?>" target="_new">Digg!</a>
					</li>
					
					<?php endwhile; endif; ?>
				  </ul>
			</div>
		</div>
<?php get_footer(); ?>