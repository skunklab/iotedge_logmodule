<?php get_header(); ?>
<div class="left">
        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
	<div class="left_articles">
		<div class="buttons"><a href="<?php comments_link('', FALSE); ?>" class="greenbtn" title="<?php comments_number('0 comments','1 comment','% comments'); ?>"><?php comments_number('0 comments','1 comment','% comments'); ?></a> <a href="<?php the_permalink() ?>" class="bluebtn" title="Read">Read</a></div>
				
<h2 class="title"><a id="post-<?php the_ID(); ?>" href="<?php the_permalink(); ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a></h2>
	<p class="description">Autor <?php the_author() ?> | <?php the_time('d.m.Y'); ?> | Category <?php the_category(', ') ?><?php edit_post_link('Edit',' | ',''); ?></p>
	<?php the_content(''); ?>
</div>
<?php endwhile; ?>		
<?php else : ?>
	<h2>Not Found</h2>
	<p>Sorry, but you are looking for something that isn't here.</p>
	<?php include (TEMPLATEPATH . "/searchform.php"); ?>
	<?php endif; ?>
	<div>
		<div class="alignleft"><?php next_posts_link('&laquo; next') ?></div>
		<div class="alignright"><?php previous_posts_link('previous &raquo;') ?></div>
	</div>
</div>		
	<div id="right">
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('right_sidebar') ) : ?>

	<div class="boxtop"></div>
	<div class="box">
		<h2><?php _e('Categories'); ?></h2>
		<ul class="contentright">
        			<?php wp_list_cats('sort_column=name&optioncount=1&hierarchical=1'); ?>
		</ul>
	</div>
	
	<div class="boxtop"></div>
	<div class="box">
		<h2><?php _e('Archives'); ?></h2>
    		<ul class="contentright">
      			<?php wp_get_archives('type=monthly'); ?>
   		</ul>	
	</div>		

	<div class="boxtop"></div>
	<div class="box">
		<h2><?php _e('Calendar'); ?></h2>
		<div align="center"><?php get_calendar(); ?></div>
	</div>

	<div class="boxtop"></div>
	<div class="box">
		<h2><?php _e('Blogroll'); ?></h2>
    		<ul class="contentright">
      			<?php wp_get_linksbyname('Blogroll', 'before=<li>&after=</li>&orderby=name&show_description=0&show_updated=1') ?>
		</ul>	
	</div>

</div>

<?php endif; ?>

<?php get_footer(); ?>