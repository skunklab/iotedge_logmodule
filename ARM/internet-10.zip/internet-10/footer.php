<div class="footer">
		<div class="gbox">
 <br />
<?php get_sidebar(); ?>

<div style="clear:both"></div>

</div>
	<p>&copy; <?php the_time('Y') ?> <a href="<?php bloginfo('url'); ?>"><?php bloginfo('name'); ?></a>. <br />Design by <a href="http://www.solucija.com/" title="Information Architecture and Web Design">Luka Cvrk</a>. Wordpressed by <a href="http://www.egoroff.info" >EGO</a> with the help of <a href="http://www.allgiftbaskets.biz">Gift Baskets</a> and {AUTHOR_TAG} | {THEMESBASE_TAG}</p>

</div>
</div>
<?php wp_footer(); ?>
</body>
</html>