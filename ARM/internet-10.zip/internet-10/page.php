<?php get_header(); ?>

		<div class="left_page">
        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			<div class="left_articles_page">





				<h2><?php the_title(); ?></h2>



				<div style="clear:both"></div>
				<?php the_content(''); ?>
				<?php edit_post_link('Edit','',''); ?>
				<?php comments_template(); ?>
			</div>
		<?php endwhile; ?>

		
		<?php else : ?>
			<h2>Not Found</h2>
			<p>Sorry, but you are looking for something that isn't here.</p>
			<?php include (TEMPLATEPATH . "/searchform.php"); ?>
		<?php endif; ?>
		</div>	
		

<?php get_footer(); ?>