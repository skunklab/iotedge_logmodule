<div class="sidebar">
<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('bottom_left') ) : ?>
    <ul><li class="listHeader"><h2><?php _e('Latest'); ?></h2></li>
         <?php wp_get_archives('type=postbypost&limit=6'); ?>
    </ul>
<?php endif; ?>
</div>



<div class="sidebar">
<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('bottom_right') ) : ?>

 <ul><li class="listHeader"><h2><?php _e('Meta'); ?></h2></li>
        <?php wp_register(); ?>
        <li><?php wp_loginout(); ?></li>
    	<li><a href="http://validator.w3.org/check/referer" title="Hopefully this page validates as XHTML 1.0 Strict">Valid <abbr title="eXtensible HyperText Markup Language">XHTML</abbr></a></li>
        <li><a href="http://jigsaw.w3.org/css-validator/check/referer" title="Valid CSS">Valid CSS</a></li>
    	<li><a href="http://gmpg.org/xfn/"><abbr title="XHTML Friends Network">XFN</abbr></a></li>
    	<li><a href="http://wordpress.org/" title="Powered by WordPress, state-of-the-art semantic personal publishing platform.">WordPress</a></li>
        <?php wp_meta(); ?>
    </ul>

<?php endif; ?>
</div>


<div class="sidebar">
<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('bottom_center') ) : ?>	
<ul class="icons"><li class="listHeader"><h2><?php _e('Subscribe'); ?></h2></li>	 
        <li><a href="<?php bloginfo('rss2_url'); ?>" title="Posts RSS feed" class="iconrss">rss posts</a></li>
		<li><a href="<?php bloginfo('comments_rss2_url'); ?>" title="Posts RSS feed" class="iconrss">rss comments</a></li>
    </ul>
<?php endif; ?>
</div>