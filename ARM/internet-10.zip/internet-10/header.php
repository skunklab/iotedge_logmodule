<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<title><?php bloginfo('name'); ?> <?php if ( is_single() ) { ?> &raquo; Blog Archive <?php } ?> <?php wp_title(); ?></title>
<meta name="generator" content="WordPress <?php bloginfo('version'); ?>" /> <!-- leave this for stats -->
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
<link rel="alternate" type="application/rss+xml" title="RSS" href="<?php bloginfo('rss2_url'); ?>" />
<?php wp_head(); ?>
</head>
<body>
<div id="content">
     <div id="header">
	   <div id="logo">
<h1><a href="<?php echo get_settings('home'); ?>/"><span class="title">Welcome to </span><?php bloginfo('name'); ?></a></h1>
<p><span class="title"><?php bloginfo('description'); ?></span></p>
	   </div>
     </div>

     <div id="tabs">
           <ul style="width: center; margin: 0 auto 0 auto">		
<li><a href="<?php echo get_settings('home'); ?>" accesskey="H">Home</a></li>	
<?php wp_list_pages('title_li=&depth=1' ); ?>
	   </ul>
     </div>

     <div id="search">
	   <form id="searchform" method="get" action="<?php echo get_settings('home'); ?>">
<p><input type="text" class="search" name="s" id="s" value="<?php echo wp_specialchars($s, 1); ?>" /> <input type="submit" value="Search" class="button" /></p>
	   </form>
     </div>	
				
     <div class="gboxtop"></div>
     <div class="gbox">
<p>A little something about you, the author. Nothing lengthy, just an overview.</p>
     </div>