﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Atlas.TimeSync.Server.Tcp
{
    public sealed class TcpTimeSyncBroadcaster : ITimeSyncBroadcaster
    {
        private const int AcceptClientsLoopDelayInMilliseconds = 1;

        private const int ClientListsInitialCapacity = 32;

        private const int TcpListenerBacklogCount = 1024;

        private TcpListener tcpListener;

        private int clientListAccessLock = 0;

        List<TcpClient> connectedClients;

        List<TcpClient> disconnectedClients;

        private Task acceptClientsLoopTask;

        private CancellationTokenSource acceptClientsLoopTaskCancellationTokenSource;

        private int broadcastingState = 0;

        private IPEndPoint listenIpEndPoint;

        private bool isDisposed = false;

        private int startStopState = 0;

        /// <summary>
        /// TcpTimeBroadcaster constructor.
        /// </summary>
        /// <param name="port">Port to listen on.</param>
        public TcpTimeSyncBroadcaster(int port)
        {
            this.listenIpEndPoint = new IPEndPoint(IPAddress.Any, port);
            this.connectedClients = new List<TcpClient>(TcpTimeSyncBroadcaster.ClientListsInitialCapacity);
            this.disconnectedClients = new List<TcpClient>(TcpTimeSyncBroadcaster.ClientListsInitialCapacity);
        }

        public void Start()
        {
            if (this.isDisposed)
                throw new ObjectDisposedException(this.GetType().Name);

            if (Interlocked.CompareExchange(ref this.startStopState, 1, 0) == 0)
            {
                this.tcpListener = new TcpListener(this.listenIpEndPoint);
                this.acceptClientsLoopTaskCancellationTokenSource = new CancellationTokenSource();
                this.acceptClientsLoopTask = new Task(async () => await AcceptClientsLoopAsync(this.acceptClientsLoopTaskCancellationTokenSource.Token),
                    this.acceptClientsLoopTaskCancellationTokenSource.Token);
                this.acceptClientsLoopTask.ConfigureAwait(false);
                this.acceptClientsLoopTask.Start();
            }
        }

        public async Task BroadcastAsync(long utcTicks)
        {
            if (this.isDisposed)
                throw new ObjectDisposedException(this.GetType().Name);

            // If the broadcasting time window is missed for some reason, ignore this update.
            if (Interlocked.CompareExchange(ref broadcastingState, 1, 0) == 0)
            {
                byte[] buffer = BitConverter.GetBytes(utcTicks);

                // Await access to clients list
                while (Interlocked.CompareExchange(ref this.clientListAccessLock, 1, 0) != 0) ;

                for (int i = 0; i < this.connectedClients.Count; i++)
                {
                    try
                    {
                        await this.connectedClients[i].GetStream().WriteAsync(buffer, 0, buffer.Length).ConfigureAwait(false);
                    }
                    catch (Exception ex)
                    {
                        if (ex is InvalidOperationException || ex is IOException || ex is SocketException)
                        {
                            // Probably client disconnected.
                            this.disconnectedClients.Add(this.connectedClients[i]);
                        }
                        else
                        {
                            throw;
                        }
                    }
                }
                Interlocked.Exchange(ref this.clientListAccessLock, 0);

                Debug.WriteLine($"({this.connectedClients.Count - this.disconnectedClients.Count}/{this.disconnectedClients.Count}) {utcTicks} : {new DateTimeOffset(utcTicks, TimeSpan.Zero).ToString("yyyy-MM-dd HH:mm:ss.ffff")}");

                if (this.disconnectedClients.Count > 0)
                {
                    for (int i = 0; i < this.disconnectedClients.Count; this.RemoveClient(this.disconnectedClients[i++])) ;
                    this.disconnectedClients.Clear();
                }
                Interlocked.Exchange(ref broadcastingState, 0);
            }
        }

        public void Stop()
        {
            if (this.isDisposed)
                throw new ObjectDisposedException(this.GetType().Name);

            if (Interlocked.CompareExchange(ref this.startStopState, 0, 1) == 1)
            {
                this.acceptClientsLoopTaskCancellationTokenSource.Cancel();
                this.acceptClientsLoopTask.Wait();
                this.tcpListener.Stop();
                this.acceptClientsLoopTask.Dispose();
                this.acceptClientsLoopTaskCancellationTokenSource.Dispose();
                this.ClearClients();
            }
        }

        public void Dispose()
        {
            this.Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (!this.isDisposed)
            {
                if (disposing)
                {
                    this.Stop();
                }
                this.isDisposed = true;
            }
        }

        private async Task AcceptClientsLoopAsync(CancellationToken cancellationToken)
        {
            cancellationToken.ThrowIfCancellationRequested();

            this.tcpListener.Start(TcpTimeSyncBroadcaster.TcpListenerBacklogCount);

            while (!cancellationToken.IsCancellationRequested)
            {
                if (this.tcpListener.Pending())
                {
                    try
                    {
                        TcpClient tcpClient = await this.tcpListener.AcceptTcpClientAsync().ConfigureAwait(false);
                        this.AddClient(tcpClient);
                    }
                    catch (Exception ex)
                    {
                        if (ex is SocketException || ex is InvalidOperationException || ex is IOException)
                        {
                            // probably disconnect during connection init
                            Debug.WriteLine($"Socket Exception : {ex.Message}");
                        }
                        else
                        {
                            Debug.WriteLine(ex.Message);
                            Debug.WriteLine(ex.StackTrace);
                            throw;
                        }
                    }
                }
                else
                {
                    await Task.Delay(AcceptClientsLoopDelayInMilliseconds).ConfigureAwait(false);
                }
            }
        }

        private void AddClient(TcpClient tcpClient)
        {
            while (Interlocked.CompareExchange(ref this.clientListAccessLock, 1, 0) != 0) ;
            this.connectedClients.Add(tcpClient);
            Interlocked.Exchange(ref this.clientListAccessLock, 0);
        }

        private void RemoveClient(TcpClient tcpClient)
        {
            while (Interlocked.CompareExchange(ref this.clientListAccessLock, 1, 0) != 0) ;
            this.connectedClients.Remove(tcpClient);
            Interlocked.Exchange(ref this.clientListAccessLock, 0);

            tcpClient.Close();
            tcpClient.Dispose();
        }

        private void ClearClients()
        {
            while (Interlocked.CompareExchange(ref this.clientListAccessLock, 1, 0) != 0) ;

            this.disconnectedClients.Clear();

            for (int i = 0; i < this.connectedClients.Count; i++)
            {
                this.connectedClients[i].Client.Disconnect(false);
                this.connectedClients[i].Close();
                this.connectedClients[i].Dispose();
            }

            this.connectedClients.Clear();
            Interlocked.Exchange(ref this.clientListAccessLock, 0);

        }
    }
}
