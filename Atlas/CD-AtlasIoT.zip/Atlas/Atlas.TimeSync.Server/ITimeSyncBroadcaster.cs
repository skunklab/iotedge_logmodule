﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atlas.TimeSync.Server
{
    /// <summary>
    /// Time Broadcaster interface.
    /// </summary>
    public interface ITimeSyncBroadcaster : IDisposable
    {
        void Start();

        Task BroadcastAsync(long utcTicks);

        void Stop();
    }
}
