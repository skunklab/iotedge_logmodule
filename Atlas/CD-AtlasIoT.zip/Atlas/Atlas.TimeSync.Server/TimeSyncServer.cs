﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace Atlas.TimeSync.Server
{
    /// <summary>
    /// Time Broadcaster base class, implementing common logic.
    /// </summary>
    public sealed class TimeSyncServer : IDisposable
    {
        /// <summary>
        /// Maximum number of calculations before getting a fresh Utc reading.
        /// </summary>
        private const int MeasurementCountResetThreshold = 16;

        /// <summary>
        /// Broadcast interval in milliseconds.
        /// </summary>
        private readonly int broadcastInterval = 0;

        /// <summary>
        /// The inner <see cref="ITimeSyncBroadcaster"/> instance.
        /// </summary>
        private readonly ITimeSyncBroadcaster broadcaster;

        /// <summary>
        /// Broadcasting state. 0 stopeed, 1 started.
        /// </summary>
        private int broadcastStartStopState = 0;

        /// <summary>
        /// <see cref="CancellcationTokenSource "/> for the broadcastTickTask.
        /// </summary>
        private CancellationTokenSource broadcastTickTaskCancellationTokenSource;

        /// <summary>
        /// Broadcasting <see cref="Task"/>.
        /// </summary>
        private Task broadcastTickTask;

        /// <summary>
        /// Returns true is this instance is disposed.
        /// </summary>
        private bool isDisposed = false;

        /// <summary>
        /// TimeBroadcasterBase constructor.
        /// </summary>
        /// <param name="interval">Time broadcast internal in milliseconds.</param>
        /// <param name="log">Log writer.</param>
        public TimeSyncServer(ITimeSyncBroadcaster broadcaster, int interval)
        {
            this.broadcaster = broadcaster;
            this.broadcastInterval = interval;
        }

        /// <summary>
        /// Stops the broadcaster and disposes it.
        /// </summary>
        public void Stop()
        {
            try
            {
                if (this.isDisposed)
                    throw new ObjectDisposedException(this.GetType().Name);

                if (Interlocked.CompareExchange(ref broadcastStartStopState, 0, 1) == 1)
                {
                    this.broadcastTickTaskCancellationTokenSource.Cancel();
                    this.broadcastTickTask.Wait();
                    this.broadcaster.Stop();
                    this.broadcastTickTaskCancellationTokenSource.Dispose();
                    this.broadcastTickTask.Dispose();
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                Debug.WriteLine(ex.StackTrace);
                throw;
            }
        }

        /// <summary>
        /// Start the broadcaster.
        /// </summary>
        public void Start()
        {
            try
            {
                if (this.isDisposed)
                    throw new ObjectDisposedException(this.GetType().Name);

                if (Interlocked.CompareExchange(ref broadcastStartStopState, 1, 0) == 0)
                {
                    this.broadcastTickTaskCancellationTokenSource = new CancellationTokenSource();
                    this.broadcastTickTask = new Task<Task>(BroadcastTick, this.broadcastTickTaskCancellationTokenSource.Token);
                    this.broadcastTickTask.ConfigureAwait(false);
                    this.broadcaster.Start();
                    this.broadcastTickTask.Start();
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                Debug.WriteLine(ex.StackTrace);
                throw;
            }
        }
        /// <summary>
        /// Performs application-defined tasks associated with freeing, releasing, or resetting 
        /// unmanaged resources.
        /// </summary>
        public void Dispose()
        {
            this.Dispose(true);
        }

        /// <summary>
        /// Performs application-defined tasks associated with freeing, releasing, or resetting 
        /// unmanaged resources.
        /// </summary>
        /// <param name="disposing">True if disposing.</param>
        private void Dispose(bool disposing)
        {
            if (!this.isDisposed)
            {
                if (disposing)
                {
                    this.Stop();
                    this.broadcaster.Dispose();
                }

                this.isDisposed = true;
            }
        }

        /// <summary>
        /// Calculate and send time.
        /// </summary>
        /// <returns>null</returns>
        private async Task BroadcastTick()
        {
            try
            {
                this.broadcastTickTaskCancellationTokenSource.Token.ThrowIfCancellationRequested();

                long utcTicks = 0;
                int measurementCount = 0;
                DateTimeOffset baseDateTimeOffset = DateTimeOffset.UtcNow;
                long baseTicks = Stopwatch.GetTimestamp();
                while (!this.broadcastTickTaskCancellationTokenSource.IsCancellationRequested)
                {
                    // Calculate Elapsed
                    long elapsedMilliseconds = ((Stopwatch.GetTimestamp() - baseTicks) * 1000) / Stopwatch.Frequency;
                    utcTicks = baseDateTimeOffset.AddMilliseconds(elapsedMilliseconds).UtcTicks;

                    await this.broadcaster.BroadcastAsync(utcTicks).ConfigureAwait(false);

                    measurementCount++;
                    if (measurementCount >= TimeSyncServer.MeasurementCountResetThreshold)
                    {
                        measurementCount = 0;
                        baseDateTimeOffset = DateTimeOffset.UtcNow;
                        baseTicks = Stopwatch.GetTimestamp();
                    }
                    await Task.Delay(broadcastInterval).ConfigureAwait(false);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                Debug.WriteLine(ex.StackTrace);
                throw;
            }
        }

    }
}

