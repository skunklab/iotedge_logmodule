﻿namespace Atlas.NetStat
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.statMain = new System.Windows.Forms.StatusStrip();
            this.tspState = new System.Windows.Forms.ToolStripStatusLabel();
            this.tspError = new System.Windows.Forms.ToolStripStatusLabel();
            this.tspMain = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.tspFilterByRemotePort = new System.Windows.Forms.ToolStripTextBox();
            this.tspKeepRefreshing = new System.Windows.Forms.ToolStripButton();
            this.spltMain = new System.Windows.Forms.SplitContainer();
            this.dgvSummary = new System.Windows.Forms.DataGridView();
            this.dgvDetails = new System.Windows.Forms.DataGridView();
            this.colLocalIP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRemoteIP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRemotePort = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEstablished = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCloseWait = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTimeWait = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colOthers = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.timKeepRefreshing = new System.Windows.Forms.Timer(this.components);
            this.colRemoteIPSummary = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colLocalIPSummary = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRemotePortSummary = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEstablishedSummary = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCloseWaitSummary = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTimeWaitSummary = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colOthersSummary = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statMain.SuspendLayout();
            this.tspMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spltMain)).BeginInit();
            this.spltMain.Panel1.SuspendLayout();
            this.spltMain.Panel2.SuspendLayout();
            this.spltMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSummary)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetails)).BeginInit();
            this.SuspendLayout();
            // 
            // statMain
            // 
            this.statMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tspState,
            this.tspError});
            this.statMain.Location = new System.Drawing.Point(0, 471);
            this.statMain.Name = "statMain";
            this.statMain.Size = new System.Drawing.Size(654, 22);
            this.statMain.TabIndex = 0;
            this.statMain.Text = "statusStrip1";
            // 
            // tspState
            // 
            this.tspState.Name = "tspState";
            this.tspState.Size = new System.Drawing.Size(42, 17);
            this.tspState.Text = "Ready!";
            // 
            // tspError
            // 
            this.tspError.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tspError.Name = "tspError";
            this.tspError.Size = new System.Drawing.Size(0, 17);
            // 
            // tspMain
            // 
            this.tspMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel1,
            this.tspFilterByRemotePort,
            this.tspKeepRefreshing});
            this.tspMain.Location = new System.Drawing.Point(0, 0);
            this.tspMain.Name = "tspMain";
            this.tspMain.Size = new System.Drawing.Size(654, 25);
            this.tspMain.TabIndex = 1;
            this.tspMain.Text = "toolStrip1";
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(109, 22);
            this.toolStripLabel1.Text = "FilterByRemotePort";
            // 
            // tspFilterByRemotePort
            // 
            this.tspFilterByRemotePort.Name = "tspFilterByRemotePort";
            this.tspFilterByRemotePort.Size = new System.Drawing.Size(100, 25);
            this.tspFilterByRemotePort.Text = "5671";
            // 
            // tspKeepRefreshing
            // 
            this.tspKeepRefreshing.Checked = true;
            this.tspKeepRefreshing.CheckOnClick = true;
            this.tspKeepRefreshing.CheckState = System.Windows.Forms.CheckState.Checked;
            this.tspKeepRefreshing.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tspKeepRefreshing.Image = ((System.Drawing.Image)(resources.GetObject("tspKeepRefreshing.Image")));
            this.tspKeepRefreshing.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tspKeepRefreshing.Name = "tspKeepRefreshing";
            this.tspKeepRefreshing.Size = new System.Drawing.Size(93, 22);
            this.tspKeepRefreshing.Text = "KeepRefreshing";
            this.tspKeepRefreshing.Click += new System.EventHandler(this.tspKeepRefreshing_Click);
            // 
            // spltMain
            // 
            this.spltMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.spltMain.Location = new System.Drawing.Point(0, 25);
            this.spltMain.Name = "spltMain";
            this.spltMain.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // spltMain.Panel1
            // 
            this.spltMain.Panel1.Controls.Add(this.dgvSummary);
            // 
            // spltMain.Panel2
            // 
            this.spltMain.Panel2.Controls.Add(this.dgvDetails);
            this.spltMain.Size = new System.Drawing.Size(654, 446);
            this.spltMain.SplitterDistance = 162;
            this.spltMain.TabIndex = 2;
            // 
            // dgvSummary
            // 
            this.dgvSummary.AllowUserToAddRows = false;
            this.dgvSummary.AllowUserToDeleteRows = false;
            this.dgvSummary.AllowUserToOrderColumns = true;
            this.dgvSummary.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvSummary.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvSummary.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSummary.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colRemoteIPSummary,
            this.colLocalIPSummary,
            this.colRemotePortSummary,
            this.colEstablishedSummary,
            this.colCloseWaitSummary,
            this.colTimeWaitSummary,
            this.colOthersSummary});
            this.dgvSummary.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvSummary.Location = new System.Drawing.Point(0, 0);
            this.dgvSummary.Name = "dgvSummary";
            this.dgvSummary.ReadOnly = true;
            this.dgvSummary.Size = new System.Drawing.Size(654, 162);
            this.dgvSummary.TabIndex = 4;
            // 
            // dgvDetails
            // 
            this.dgvDetails.AllowUserToAddRows = false;
            this.dgvDetails.AllowUserToDeleteRows = false;
            this.dgvDetails.AllowUserToOrderColumns = true;
            this.dgvDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvDetails.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDetails.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colLocalIP,
            this.colRemoteIP,
            this.colRemotePort,
            this.colEstablished,
            this.colCloseWait,
            this.colTimeWait,
            this.colOthers});
            this.dgvDetails.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDetails.Location = new System.Drawing.Point(0, 0);
            this.dgvDetails.Name = "dgvDetails";
            this.dgvDetails.ReadOnly = true;
            this.dgvDetails.Size = new System.Drawing.Size(654, 280);
            this.dgvDetails.TabIndex = 0;
            // 
            // colLocalIP
            // 
            this.colLocalIP.DataPropertyName = "LocalIP";
            this.colLocalIP.Frozen = true;
            this.colLocalIP.HeaderText = "LocalIP";
            this.colLocalIP.Name = "colLocalIP";
            this.colLocalIP.ReadOnly = true;
            this.colLocalIP.Width = 68;
            // 
            // colRemoteIP
            // 
            this.colRemoteIP.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colRemoteIP.DataPropertyName = "RemoteIP";
            this.colRemoteIP.HeaderText = "RemoteIP";
            this.colRemoteIP.Name = "colRemoteIP";
            this.colRemoteIP.ReadOnly = true;
            // 
            // colRemotePort
            // 
            this.colRemotePort.DataPropertyName = "RemotePort";
            this.colRemotePort.HeaderText = "RemotePort";
            this.colRemotePort.Name = "colRemotePort";
            this.colRemotePort.ReadOnly = true;
            this.colRemotePort.Width = 88;
            // 
            // colEstablished
            // 
            this.colEstablished.DataPropertyName = "Established";
            this.colEstablished.HeaderText = "Established";
            this.colEstablished.Name = "colEstablished";
            this.colEstablished.ReadOnly = true;
            this.colEstablished.Width = 86;
            // 
            // colCloseWait
            // 
            this.colCloseWait.DataPropertyName = "CloseWait";
            this.colCloseWait.HeaderText = "CloseWait";
            this.colCloseWait.Name = "colCloseWait";
            this.colCloseWait.ReadOnly = true;
            this.colCloseWait.Width = 80;
            // 
            // colTimeWait
            // 
            this.colTimeWait.DataPropertyName = "TimeWait";
            this.colTimeWait.HeaderText = "TimeWait";
            this.colTimeWait.Name = "colTimeWait";
            this.colTimeWait.ReadOnly = true;
            this.colTimeWait.Width = 77;
            // 
            // colOthers
            // 
            this.colOthers.DataPropertyName = "Others";
            this.colOthers.HeaderText = "Others";
            this.colOthers.Name = "colOthers";
            this.colOthers.ReadOnly = true;
            this.colOthers.Width = 63;
            // 
            // timKeepRefreshing
            // 
            this.timKeepRefreshing.Enabled = true;
            this.timKeepRefreshing.Interval = 5000;
            this.timKeepRefreshing.Tick += new System.EventHandler(this.timKeepRefreshing_Tick);
            // 
            // colRemoteIPSummary
            // 
            this.colRemoteIPSummary.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colRemoteIPSummary.DataPropertyName = "RemoteIP";
            this.colRemoteIPSummary.HeaderText = "RemoteIP";
            this.colRemoteIPSummary.Name = "colRemoteIPSummary";
            this.colRemoteIPSummary.ReadOnly = true;
            // 
            // colLocalIPSummary
            // 
            this.colLocalIPSummary.DataPropertyName = "LocalIP";
            this.colLocalIPSummary.HeaderText = "LocalIP";
            this.colLocalIPSummary.Name = "colLocalIPSummary";
            this.colLocalIPSummary.ReadOnly = true;
            this.colLocalIPSummary.Visible = false;
            this.colLocalIPSummary.Width = 68;
            // 
            // colRemotePortSummary
            // 
            this.colRemotePortSummary.DataPropertyName = "RemotePort";
            this.colRemotePortSummary.HeaderText = "RemotePort";
            this.colRemotePortSummary.Name = "colRemotePortSummary";
            this.colRemotePortSummary.ReadOnly = true;
            this.colRemotePortSummary.Width = 88;
            // 
            // colEstablishedSummary
            // 
            this.colEstablishedSummary.DataPropertyName = "Established";
            this.colEstablishedSummary.HeaderText = "Established";
            this.colEstablishedSummary.Name = "colEstablishedSummary";
            this.colEstablishedSummary.ReadOnly = true;
            this.colEstablishedSummary.Width = 86;
            // 
            // colCloseWaitSummary
            // 
            this.colCloseWaitSummary.DataPropertyName = "CloseWait";
            this.colCloseWaitSummary.HeaderText = "CloseWait";
            this.colCloseWaitSummary.Name = "colCloseWaitSummary";
            this.colCloseWaitSummary.ReadOnly = true;
            this.colCloseWaitSummary.Width = 80;
            // 
            // colTimeWaitSummary
            // 
            this.colTimeWaitSummary.DataPropertyName = "TimeWait";
            this.colTimeWaitSummary.HeaderText = "TimeWait";
            this.colTimeWaitSummary.Name = "colTimeWaitSummary";
            this.colTimeWaitSummary.ReadOnly = true;
            this.colTimeWaitSummary.Width = 77;
            // 
            // colOthersSummary
            // 
            this.colOthersSummary.DataPropertyName = "Others";
            this.colOthersSummary.HeaderText = "Others";
            this.colOthersSummary.Name = "colOthersSummary";
            this.colOthersSummary.ReadOnly = true;
            this.colOthersSummary.Width = 63;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(654, 493);
            this.Controls.Add(this.spltMain);
            this.Controls.Add(this.tspMain);
            this.Controls.Add(this.statMain);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmMain";
            this.Text = "Atlas - Advanced Netstat";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.statMain.ResumeLayout(false);
            this.statMain.PerformLayout();
            this.tspMain.ResumeLayout(false);
            this.tspMain.PerformLayout();
            this.spltMain.Panel1.ResumeLayout(false);
            this.spltMain.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.spltMain)).EndInit();
            this.spltMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSummary)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetails)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statMain;
        private System.Windows.Forms.ToolStrip tspMain;
        private System.Windows.Forms.SplitContainer spltMain;
        private System.Windows.Forms.DataGridView dgvSummary;
        private System.Windows.Forms.DataGridView dgvDetails;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripTextBox tspFilterByRemotePort;
        private System.Windows.Forms.ToolStripButton tspKeepRefreshing;
        private System.Windows.Forms.Timer timKeepRefreshing;
        private System.Windows.Forms.ToolStripStatusLabel tspState;
        private System.Windows.Forms.DataGridViewTextBoxColumn colLocalIP;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRemoteIP;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRemotePort;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEstablished;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCloseWait;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTimeWait;
        private System.Windows.Forms.DataGridViewTextBoxColumn colOthers;
        private System.Windows.Forms.ToolStripStatusLabel tspError;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRemoteIPSummary;
        private System.Windows.Forms.DataGridViewTextBoxColumn colLocalIPSummary;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRemotePortSummary;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEstablishedSummary;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCloseWaitSummary;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTimeWaitSummary;
        private System.Windows.Forms.DataGridViewTextBoxColumn colOthersSummary;
    }
}

