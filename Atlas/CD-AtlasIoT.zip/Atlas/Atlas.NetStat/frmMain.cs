﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atlas.NetStat
{

    public partial class frmMain : Form
    {
        Dictionary<string, NetStatDetails> NetStats = new Dictionary<string, NetStatDetails>();
        Dictionary<string, NetStatDetails> NetStatSummary = new Dictionary<string, NetStatDetails>();
        public void GetNetStat()
        {
            try
            {
                var ip = System.Net.NetworkInformation.IPGlobalProperties.GetIPGlobalProperties();
                foreach (NetStatDetails nstat in NetStats.Values)
                    nstat.ResetConunters();

                foreach (NetStatDetails nstat in NetStatSummary.Values)
                    nstat.ResetConunters();

                foreach (var tcp in ip.GetActiveTcpConnections())
                {
                    NetStatDetails nstat;
                    NetStatDetails nstatsummary;
                    string key = tcp.LocalEndPoint.Address.ToString() + "|" + tcp.RemoteEndPoint.Address.ToString() + "|" + tcp.RemoteEndPoint.Port;
                    string summarykey = tcp.RemoteEndPoint.Address.ToString() + "|" + tcp.RemoteEndPoint.Port;

                    if (NetStats.ContainsKey(key))
                        nstat = NetStats[key];
                    else
                    {
                        nstat = new NetStatDetails(tcp.LocalEndPoint.Address.ToString(), tcp.RemoteEndPoint.Address.ToString(), tcp.RemoteEndPoint.Port);
                        NetStats.Add(key, nstat);
                    }

                    if (NetStatSummary.ContainsKey(summarykey))
                        nstatsummary = NetStatSummary[summarykey];
                    else
                    {
                        nstatsummary = new NetStatDetails(string.Empty, tcp.RemoteEndPoint.Address.ToString(), tcp.RemoteEndPoint.Port);
                        NetStatSummary.Add(summarykey, nstatsummary);
                    }

                    switch (tcp.State)
                    {
                        case System.Net.NetworkInformation.TcpState.Established:
                            nstat.Established++;
                            nstatsummary.Established++;
                            break;
                        case System.Net.NetworkInformation.TcpState.CloseWait:
                            nstat.CloseWait++;
                            nstatsummary.CloseWait++;
                            break;
                        case System.Net.NetworkInformation.TcpState.TimeWait:
                            nstat.TimeWait++;
                            nstatsummary.TimeWait++;
                            break;
                        default:
                            nstat.Others++;
                            nstatsummary.Others++;
                            break;
                    }
                }

                List<NetStatDetails> Tobind = NetStats.Values.ToList();
                List<NetStatDetails> SummaryTobind = NetStatSummary.Values.ToList();
                int FilterPort = -1;
                if (int.TryParse(tspFilterByRemotePort.Text, out FilterPort))
                {
                    Tobind = Tobind.Where(netstat => netstat.RemotePort == FilterPort).ToList();
                    SummaryTobind = SummaryTobind.Where(netstat => netstat.RemotePort == FilterPort).ToList();
                }

                dgvDetails.DataSource = Tobind;
                dgvSummary.DataSource = SummaryTobind;
                tspState.Text = "Last Refreshed - " + DateTime.Now.ToString("ddMMMyy HH:mm:ss");
            }
            catch (Exception ex)
            {
                tspError.Text = "| @" + DateTime.Now.ToString("ddMMMyy HH:mm:ss") +  " - " + ex.Message;
            }
        }

        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            GetNetStat();
        }

        private void tspKeepRefreshing_Click(object sender, EventArgs e)
        {

        }

        private void timKeepRefreshing_Tick(object sender, EventArgs e)
        {
            tspKeepRefreshing.Enabled = false;
            if (tspKeepRefreshing.Checked)
                GetNetStat();

            tspKeepRefreshing.Enabled = true;
        }
    }


    public class NetStatDetails
    {
        public NetStatDetails(string LocalIP, string RemoteIP, int RemotePort)
        {
            this.LocalIP = LocalIP;
            this.RemoteIP = RemoteIP;
            this.RemotePort = RemotePort;
        }

        public void ResetConunters()
        {
            TimeWait = CloseWait = Established = Others = 0;
        }

        public string LocalIP { get; set; }
        public string RemoteIP { get; set; }
        public int RemotePort { get; set; }
        public long Established { get; set; }
        public long CloseWait { get; set; }
        public long TimeWait { get; set; }
        public long Others { get; set; }
    }
}
