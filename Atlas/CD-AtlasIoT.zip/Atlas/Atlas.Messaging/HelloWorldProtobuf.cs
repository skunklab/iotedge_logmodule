﻿using Atlas.Common;
using System;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Azure.Devices.Client;
//using Microsoft.Azure.EventHubs;
using Microsoft.Azure.Devices;
using System.IO;

namespace Atlas.IoT
{
    //Implementation which shows using protobuf as serializer instead of json for the payload.
    //Sample given here is using protobuf csharp. protobuf.net can be used in similar way.
    //Make sure you understand the differences between the two protobuf implementations for c#
    //refer here - https://stackoverflow.com/questions/2522376/how-to-choose-between-protobuf-csharp-port-and-protobuf-net
    //Beware - There are some on-the-wire differences between same structure serialized using these two implementations.
    public class HelloWorldProtobuf : IMessageProvider
    {
        static int seqnum = 0;

        public override Microsoft.Azure.Devices.Client.Message GetIoTHubPayLoad(int MessageIndex)
        {
            Interlocked.Increment(ref seqnum);
            Guid id = Guid.NewGuid();

            UTCDateTime.Builder utcdt = UTCDateTime.CreateBuilder();
            utcdt.SetUTCDay(DateTime.UtcNow.Day);
            utcdt.SetUTCMonth(DateTime.UtcNow.Month);
            utcdt.SetUTCYear(DateTime.UtcNow.Year);
            utcdt.SetUTCHour(DateTime.UtcNow.Hour);
            utcdt.SetUTCMin(DateTime.UtcNow.Minute);
            utcdt.SetUTCSecond(DateTime.UtcNow.Second);
            utcdt.SetUTCMilliSecond(DateTime.UtcNow.Millisecond);

            Protopayload.Builder protopayld = Protopayload.CreateBuilder();
            protopayld.SetMessageSentTimestamp(utcdt.Build());
            protopayld.SetMessage("Hello World!");
            protopayld.SetMessageId(id.ToString());
            protopayld.SetSequenceId(seqnum);
            ProtoHello.Builder protoH = ProtoHello.CreateBuilder();
            protoH.SetDeviceid(DeviceId);
            protoH.SetPayload(protopayld.Build());
            ProtoHello protoHello = protoH.Build();

            byte[] serialized;
            MemoryStream protoBuffer = new MemoryStream();
            protoHello.WriteTo(protoBuffer);
            serialized = protoBuffer.ToArray();

            Microsoft.Azure.Devices.Client.Message msg = new Microsoft.Azure.Devices.Client.Message(serialized);
            msg.Properties.Add("Identifier", id.ToString());
            return msg;
        }

        public override void Setup(string DeviceId, string ConfigData, int MessageDelay)
        {
            base.Setup(DeviceId, ConfigData, MessageDelay);
            //TODO: Do onetime custom setup here per device
        }

        public override Task WaitForNextMessage(int TimeSpentOnOtherThings, int MessageIndex, CancellationToken StopTest)
        {
            return base.WaitForNextMessage(TimeSpentOnOtherThings, MessageIndex, StopTest);

            //TODO: Do custom delays here between subsequent messages for a device
        }
    }
}
