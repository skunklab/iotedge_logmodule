﻿using Atlas.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure.Devices.Client;
using System.Threading;

namespace Atlas.IoT
{
    class BalaProvider : IMessageProvider
    {
        const string DataBufferPattern = "{\"deviceTimestamp\":\"{0}\",\"sDate\":\"{1}\",\"sTime\":\"{2}\",\"Cooler_Door_1_Temp_Upper\":\"1.4\",\"Cooler_Door_3_Temp_Middle\":\"1.2\",\"Cooler_Door_2_Temp_Upper\":\"1.1\",\"Cooler_Door_1_Temp_Lower\":\"1.6\",\"Cooler_Door_3_Temp_Upper\":\"1\",\"Cooler_Door_2_Temp_Lower\":\"0.9\",\"Cooler_Door_1_Temp_Middle\":\"1.8\",\"Cooler_Bottom_EvapLine\":\"-0.5\",\"Cooler_Door_2_Temp_Middle\":\"1.3\",\"Cooler_Temp_EvapLine\":\"1.2\",\"Cooler_Press_Lo_TXV\":\"57.4\",\"Cooler_Press_Hi_TXV\":\"240.02\",\"Cooler_Press_Evap_Out\":\"57.57\",\"Cooler_ACV_Compressor\":\"120.58\",\"Cooler_Amps_Compressor\":\"7.57\",\"Freezer_Door_1_Temp_Upper\":\"-20.6\",\"Freezer_Bottom_EvapLine\":\"-24.7\",\"Freezer_Door_2_Temp_Upper\":\"-21.3\",\"Freezer_Door_1_Temp_Lower\":\"-19.6\",\"Freezer_Door_3_Temp_Upper\":\"-20.8\",\"Freezer_Door_2_Temp_Lower\":\"-20.5\",\"Freezer_Door_1_Temp_Middle\":\"-20.2\",\"Freezer_Door_3_Temp_Lower\":\"-20.1\",\"Freezer_Door_2_Temp_Middle\":\"-19.7\",\"Freezer_Temp_EvapLine\":\"-21.1\",\"Freezer_Press_Lo_TXV\":\"52.52\",\"Freezer_Press_Hi_TXV\":\"221.14\",\"Freezer_Press_Evap_Out\":\"18.6\",\"Freezer_ACV_Compressor\":\"209.25\",\"Freezer_Amps_Compressor\":\"7.17\",\"Freezer_Defrost_Cycle\":\"0\",\"Freezer_Fan\":\"1\",\"Cooler_Fan\":\"1\",\"Freezer_Doors_R1\":\"0\",\"Freezer_Doors_R2\":\"0\",\"Cooler_Doors_R4\":\"0\",\"Cooler_Doors_R5\":\"0\",\"Cooler_Watt_Compressor\":\"912.8\",\"Freezer_Watt_Compressor\":\"1500.3\"}";
        static int seqnum = 0;

        public override Microsoft.Azure.Devices.Client.Message GetIoTHubPayLoad(int MessageIndex)
        {
            Interlocked.Increment(ref seqnum);
            Guid id = Guid.NewGuid();
            Microsoft.Azure.Devices.Client.Message msg = new Microsoft.Azure.Devices.Client.Message(Encoding.UTF8.GetBytes(DataBufferPattern.Replace("{0}", DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.ffffffZ")).Replace("{1}",
                         DateTime.UtcNow.ToString("yyyy-MM-dd")).Replace("{2}", DateTime.UtcNow.ToString("HH:mm:ss"))));
            msg.Properties.Add("Identifier", id.ToString());
            return msg;
        }

        public override void Setup(string DeviceId, string ConfigData, int MessageDelay)
        {
            base.Setup(DeviceId, ConfigData, MessageDelay);
            //TODO: Do onetime custom setup here per device
        }

        public async override Task WaitForNextMessage(int TimeSpentOnOtherThings, int MessageIndex, CancellationToken StopTest)
        {

            await base.WaitForNextMessage(TimeSpentOnOtherThings, MessageIndex, StopTest);
            int delay = 200 - TimeSpentOnOtherThings;

            await Task.Delay(delay < 0 ? 0 : delay).ConfigureAwait(false);
            //TODO: Do custom delays here between subsequent messages for a device
        }
    }
}
