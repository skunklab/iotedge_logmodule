﻿using Atlas.Common;
using System;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Azure.Devices.Client;
//using Microsoft.Azure.EventHubs;
using Microsoft.Azure.Devices;

namespace Atlas.IoT
{
    public class HelloWorldMessageProvider : IMessageProvider
    {
        const string DataBufferPattern = "{\"deviceid\": {0},\"payload\": {\"messageSentTimestamp\": \"{1}\",\"message\": {2},\"messageId\": \"{3}\",\"sequenceId\": \"{4}\"}}";
        static int seqnum = 0;

        public override Microsoft.Azure.Devices.Client.Message GetIoTHubPayLoad(int MessageIndex)
        {
            Interlocked.Increment(ref seqnum);
            Guid id = Guid.NewGuid();
            Microsoft.Azure.Devices.Client.Message msg = new Microsoft.Azure.Devices.Client.Message(Encoding.UTF8.GetBytes(DataBufferPattern.Replace("{0}", DeviceId).
                        Replace("{1}", DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.ffffffZ")).Replace("{2}",
                        "Hello World!").Replace("{3}", id.ToString())));
            msg.Properties.Add("Identifier", id.ToString());
            return msg;
        }

        public override void Setup(string DeviceId, string ConfigData, int MessageDelay)
        {
            base.Setup(DeviceId, ConfigData, MessageDelay);
            //TODO: Do onetime custom setup here per device
        }

        public override Task WaitForNextMessage(int TimeSpentOnOtherThings, int MessageIndex, CancellationToken StopTest)
        {
            return base.WaitForNextMessage(TimeSpentOnOtherThings, MessageIndex, StopTest);

            //TODO: Do custom delays here between subsequent messages for a device
        }
    }
}
