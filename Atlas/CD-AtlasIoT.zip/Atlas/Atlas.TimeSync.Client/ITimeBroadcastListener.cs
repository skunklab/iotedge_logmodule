﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Atlas.TimeSync.Client
{
    /// <summary>
    /// Time broadcast listener interface.
    /// </summary>
    public interface ITimeBroadcastListener : IDisposable
    {
        /// <summary>
        /// Start the broadcast listener.
        /// </summary>
        void Start();

        Task ReceiveBroadcastAsync(Action<long> updateTimeCallBack);

        /// <summary>
        /// Stop the broadcast listener.
        /// </summary>
        void Stop();
    }
}
