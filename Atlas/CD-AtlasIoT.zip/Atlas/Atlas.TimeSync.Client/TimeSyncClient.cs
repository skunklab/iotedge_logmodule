﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Atlas.TimeSync.Client
{
    public sealed class TimeSyncClient : IDisposable
    {
        private const double SnrQualityGate = 1.0;

        private CancellationTokenSource cancellationTokenSource;
        private int startStopState = 0;
        private Task receiveLoopTask;

        private volatile int updateResultsState = 0;

        private double[] history;
        private int historyIndex = 0;

        private DateTimeOffset lastUpdated;
        private DateTimeOffset lastUpdatedCache;

        private DateTimeOffset serverDateTime;
        private DateTimeOffset serverDateTimeCache;

        private long updateCount = 0;
        private long updateCountCache = 0;

        private int updateCountRolloverCount = 0;

        private double averageDifferenceInMilliseconds = 0;
        private double averageDifferenceInMillisecondsCache = 0;

        private double differenceInMilliseconds = 0;
        private double differenceInMillisecondsCache = 0;

        private byte quality = 0;
        private byte qualityCache = 0;

        private bool isDisposed = false;

        private ITimeBroadcastListener broadcastListener;

        public double DifferenceInMilliseconds
        {
            get
            {
                if (this.isDisposed)
                    throw new ObjectDisposedException(this.GetType().Name);

                return updateResultsState == 0 ? this.differenceInMillisecondsCache = this.differenceInMilliseconds : this.differenceInMillisecondsCache;
            }
        }

        public double AverageDifferenceInMilliseconds
        {
            get
            {
                if (this.isDisposed)
                    throw new ObjectDisposedException(this.GetType().Name);

                return updateResultsState == 0 ? this.averageDifferenceInMillisecondsCache = this.averageDifferenceInMilliseconds : this.averageDifferenceInMillisecondsCache;
            }
        }
        /// <summary>
        /// 0 : Unknown, 1 : Questionable, 2 : Acceptable
        /// </summary>
        public byte TimeBroadcastQuality
        {
            get
            {
                if (this.isDisposed)
                    throw new ObjectDisposedException(this.GetType().Name);

                return updateResultsState == 0 ? this.qualityCache = this.quality : this.qualityCache;
            }
        }

        public DateTimeOffset LastUpdateReceived
        {
            get
            {
                if (this.isDisposed)
                    throw new ObjectDisposedException(this.GetType().Name);

                return updateResultsState == 0 ? this.lastUpdatedCache = this.lastUpdated : this.lastUpdatedCache;
            }
        }

        public DateTimeOffset ServerUtcDateTime
        {
            get
            {
                if (this.isDisposed)
                    throw new ObjectDisposedException(this.GetType().Name);

                return updateResultsState == 0 ? this.serverDateTimeCache = this.serverDateTime : this.serverDateTimeCache;
            }
        }

        public long UpdateCount
        {
            get
            {
                if (this.isDisposed)
                    throw new ObjectDisposedException(this.GetType().Name);

                return updateResultsState == 0 ? this.updateCountCache = this.updateCount : this.updateCountCache;
            }
        }

        public DateTimeOffset AdjustedUtcDateTimeOffset
        {
            get
            {
                if (this.isDisposed)
                    throw new ObjectDisposedException(this.GetType().Name);

                return DateTimeOffset.UtcNow.AddMilliseconds(this.DifferenceInMilliseconds);
            }

        }

        public DateTimeOffset AdjustedUtcDateTimeOffsetAverage
        {
            get
            {
                if (this.isDisposed)
                    throw new ObjectDisposedException(this.GetType().Name);

                return DateTimeOffset.UtcNow.AddMilliseconds(this.AverageDifferenceInMilliseconds);
            }
        }

        public TimeSyncClient(ITimeBroadcastListener broadcastListener, int snrBufferSize = 12)
        {
            this.history = new double[snrBufferSize];
            this.broadcastListener = broadcastListener;
        }

        public void Start()
        {
            try
            {
                if (this.isDisposed)
                    throw new ObjectDisposedException(this.GetType().Name);

                if (Interlocked.CompareExchange(ref startStopState, 1, 0) == 0)
                {
                    this.cancellationTokenSource = new CancellationTokenSource();
                    this.receiveLoopTask = new Task(async () => await ReceiveLoop(this.cancellationTokenSource.Token), this.cancellationTokenSource.Token);
                    this.receiveLoopTask.ConfigureAwait(false);
                    this.broadcastListener.Start();
                    this.receiveLoopTask.Start();
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                Debug.WriteLine(ex.StackTrace);
                throw;
            }

        }

        public void Stop()
        {
            try
            {
                if (this.isDisposed)
                    throw new ObjectDisposedException(this.GetType().Name);

                if (Interlocked.CompareExchange(ref startStopState, 0, 1) == 1)
                {
                    this.cancellationTokenSource.Cancel();
                    this.receiveLoopTask.Wait();
                    this.receiveLoopTask.Dispose();
                    this.cancellationTokenSource.Dispose();
                    this.broadcastListener.Stop();
                    this.Reset();
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                Debug.WriteLine(ex.StackTrace);
                throw;
            }
        }


        public void Dispose()
        {
            this.Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (!this.isDisposed)
            {
                if (disposing)
                {
                    this.Stop();
                }

                this.isDisposed = true;
            }
        }

        private void OnReceived(long utcTicks)
        {
            // If another update comes before this is finished, ignore.
            if (Interlocked.CompareExchange(ref updateResultsState, 1, 0) == 0)
            {
                DateTimeOffset utcActual = DateTimeOffset.UtcNow;
                DateTimeOffset utcReceived = new DateTimeOffset(utcTicks, TimeSpan.Zero);
                //Interlocked.Exchange(ref this.differenceInMilliseconds, (utcReceived - utcActual).TotalMilliseconds);
                this.differenceInMilliseconds = (utcReceived - utcActual).TotalMilliseconds;

                historyIndex = historyIndex > history.Length - 1 ? 0 : historyIndex;

                history[historyIndex++] = this.differenceInMilliseconds;

                this.CalculateStats(out double snr, out double mean);

                //Interlocked.Exchange(ref this.averageDifferenceInMilliseconds, mean);
                this.averageDifferenceInMilliseconds = mean;
                if (this.updateCount >= this.history.Length && snr > 1)
                {
                    this.quality = 2; // Acceptable
                }
                else
                {
                    this.quality = 1; // Questionable
                }

                this.lastUpdated = utcActual;
                Debug.WriteLine($"{this.quality}, {snr}, {mean}, UtcReceived: {utcReceived.ToString("yyyy-MM-dd HH:mm:ss.ffff")}, UtcActual: {utcActual.ToString("yyyy-MM-dd HH:mm:ss.ffff")}, ({(utcReceived - utcActual).TotalMilliseconds})");
                this.serverDateTime = utcReceived;

                //Interlocked.Increment(ref this.updateCount);
                this.updateCount++;

                if (this.updateCount >= long.MaxValue || this.updateCount < 0)
                {
                    //Interlocked.Exchange(ref this.updateCount, 0);
                    this.updateCount = 0;
                    //Interlocked.Increment(ref this.updateCountRolloverCount);
                    this.updateCountRolloverCount++;
                }
                Interlocked.Exchange(ref updateResultsState, 0);
            }
        }

        private async Task ReceiveLoop(CancellationToken cancellationToken)
        {
            while (!cancellationToken.IsCancellationRequested)
            {
                await this.broadcastListener.ReceiveBroadcastAsync(this.OnReceived).ConfigureAwait(false);
                await Task.Delay(1).ConfigureAwait(false);
            }
        }

        private void CalculateStats(out double snr, out double mean)
        {
            double sum = 0;
            for (int i = 0; i < history.Length; sum += history[i++]) ;
            mean = sum / history.Length;

            sum = 0;
            for (int i = 0; i < history.Length; sum += Math.Pow(history[i++] - mean, 2)) ;
            double std = Math.Sqrt(sum / history.Length);

            snr = Math.Abs(mean / std);
        }

        private void Reset()
        {
            for (int i = 0; i < this.history.Length; this.history[i++] = 0) ;
            this.quality = this.qualityCache = 0; // Unknown
            this.differenceInMilliseconds = this.differenceInMillisecondsCache = 0;
            this.averageDifferenceInMilliseconds = this.averageDifferenceInMilliseconds = 0;
            this.serverDateTime = this.serverDateTimeCache = DateTimeOffset.MinValue;
            this.lastUpdated = this.lastUpdatedCache = DateTimeOffset.MinValue;
            this.updateCount = this.updateCountCache = 0;
            this.updateCountRolloverCount = 0;
        }
    }
}
