﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Atlas.TimeSync.Client.Tcp
{
    public sealed class TcpTimeBroadcastListener : ITimeBroadcastListener
    {
        private TcpClient tcpClient;
        private IPEndPoint remoteIPEndPoint;
        private NetworkStream tcpStream;
        private int startStopState = 0;

        private int receivingState = 0;

        private bool isDisposed = false;

        private byte[] connnectionCheckPeekBuffer = new byte[1];

        public TcpTimeBroadcastListener(IPEndPoint remoteIPEndPoint)
        {
            this.remoteIPEndPoint = remoteIPEndPoint;
        }

        public async Task ReceiveBroadcastAsync(Action<long> updateTimeCallBack)
        {
            if (this.isDisposed)
                throw new ObjectDisposedException(this.GetType().Name);

            if (Interlocked.CompareExchange(ref this.receivingState, 1, 0) == 0)
            {
                try
                {
                    // If Disconnected
                    if (!this.tcpClient.Connected || (this.tcpClient.Client.Poll(0, SelectMode.SelectRead) && this.tcpClient.Client.Receive(this.connnectionCheckPeekBuffer, SocketFlags.Peek) == 0))
                    {
                        this.tcpClient.Close();
                        this.tcpClient.Dispose();
                        this.tcpClient = new TcpClient();
                        this.tcpClient.Connect(this.remoteIPEndPoint);
                        this.tcpStream = this.tcpClient.GetStream();
                    }

                    if (this.tcpClient.Available > 0)
                    {
                        byte[] buffer = new byte[this.tcpClient.Available];
                        if (this.tcpStream.DataAvailable)
                        {
                            await this.tcpStream.ReadAsync(buffer, 0, buffer.Length).ConfigureAwait(false);

                            updateTimeCallBack(BitConverter.ToInt64(buffer, 0));
                        }
                    }
                }
                catch (Exception ex)
                {
                    if (ex is SocketException || ex is InvalidOperationException || ex is IOException)
                    {
                        Debug.WriteLine($"Could not connect to server. : {ex.Message}");
                    }
                    else
                    {
                        Debug.WriteLine(ex.Message);
                        Debug.WriteLine(ex.StackTrace);
                        throw;
                    }
                }
                finally
                {
                    Interlocked.Exchange(ref this.receivingState, 0);
                }
            }
        }

        public void Start()
        {
            try
            {
                if (this.isDisposed)
                    throw new ObjectDisposedException(this.GetType().Name);

                // Handle redundant calls. 
                if (Interlocked.CompareExchange(ref this.startStopState, 1, 0) == 0)
                {
                    this.tcpClient = new TcpClient();
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                Debug.WriteLine(ex.StackTrace);
                throw;
            }
        }

        public void Stop()
        {
            try
            {
                if (this.isDisposed)
                    throw new ObjectDisposedException(this.GetType().Name);

                // Handle redundant calls. 
                if (Interlocked.CompareExchange(ref this.startStopState, 0, 1) == 1)
                {
                    if (this.tcpClient.Connected)
                    {
                        this.tcpStream.Close();
                        this.tcpClient.Close();
                        this.tcpClient.Dispose();
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                Debug.WriteLine(ex.StackTrace);
                throw;
            }
        }

        public void Dispose()
        {
            this.Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (!this.isDisposed)
            {
                if (disposing)
                {
                    this.Stop();
                }
                this.isDisposed = true;
            }
        }
    }
}
