﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atlas.Common
{
    public class CommandInfo
    {
        public CommandInfo(string DeviceId, string IoTHub, int CommandIndex, DateTime TimeStamp, int ResponseTime, byte[] PayLoad, byte QoT)
        {
            this.DeviceId = DeviceId;
            this.IoTHub = IoTHub;
            this.CommandIndex = CommandIndex;
            this.TimeStamp = TimeStamp;
            this.ResponseTime = ResponseTime;
            this.PayLoad = PayLoad;
            this.QoT = QoT;
        }
        public static int CurrentRunId;
        public static string CurrentAgentName;
        public int CommandId { get; set; } = -1;
        public int RunId { get { return CurrentRunId; } }
        public string AgentName { get { return CurrentAgentName; } }
        public string DeviceId { get; private set; }
        public string IoTHub { get; private set; }
        public int CommandIndex { get; private set; }
        public DateTime TimeStamp { get; private set; }
        public byte QoT { get; private set; }
        public int ResponseTime { get; private set; }
        public byte[] PayLoad { get; private set; }
    }
}
