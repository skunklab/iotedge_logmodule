﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atlas.Common
{
    public class ExceptionInfo
    {
        public ExceptionInfo(string DeviceId, string IoTHub, int MessageIndex, string ExceptionType, string ExceptionMessage, 
            DateTime TimeStamp, int ResponseTime, byte[] PayLoad, byte QoT)
        {
            this.DeviceId = DeviceId;
            this.IoTHub = IoTHub;
            this.MessageIndex = MessageIndex;
            this.ExceptionType = ExceptionType.Length > 50 ? ExceptionType.Substring(0, 50) : ExceptionType;
            this.ExceptionMessage = ExceptionMessage.Length > 250 ? ExceptionMessage.Substring(0, 250) : ExceptionMessage;
            this.TimeStamp = TimeStamp;
            this.ResponseTime = ResponseTime;
            this.PayLoad = PayLoad;
            this.QoT = QoT;
        }

        public static int CurrentRunId;
        public static string CurrentAgentName;
        public int ExceptionId { get; set; } = -1;
        public int RunId { get { return CurrentRunId; } }
        public string AgentName { get { return CurrentAgentName; } }
        public string DeviceId { get; private set; }
        public string IoTHub { get; private set; }
        public int MessageIndex { get; private set; }
        public string ExceptionType { get; private set; }
        public string ExceptionMessage { get; private set; }
        public DateTime TimeStamp { get; private set; }
        public int ResponseTime { get; private set; }
        public byte QoT { get; private set; }
        public byte[] PayLoad { get; private set; }
    }
}
