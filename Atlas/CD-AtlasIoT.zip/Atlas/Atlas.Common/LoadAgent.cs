﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atlas.Common
{
    public enum TestRunStatus
    {
        Ready,
        RunInitiated,
        AgentWarmingUp,
        TestStarted,
        StopRequested,
        AgentRampingDown,
        TestStopped,
        ShutdownInitiated,
        TestShutdown,
        AgentShutDown,
        TestCompleted
    }

    public class TestRun
    {
        public TestRun(long RunGroup, DateTime StartTestAt)
        {
            this.RunGroup = RunGroup;
            this.StartTestAt = StartTestAt;
        }

        public int RunId { get; set; }
        public long TotalDevices{ get; set; }
        public long TotalMessages { get; set; }
        public long DeviceConnectTime { get; set; }

        public DateTime StartTestAt { get; set; }

        public long MessagesSent { get; set; }
        public long TotalPayloadSizeInBytes { get; set; }

        public int AverageResponseTimeInMS { get; set; }
        public int Percentile95ResponseTimeInMS { get; set; }
        public int MessagesPerMinute { get; set; }
        public decimal MBPerMinute { get; set; }

        public long ExceptionsRecieved { get; set; }

        public DateTime TestStart { get; set; }
        public DateTime TestEnd { get; set; }

        public TestRunStatus RunState { get; set; }

        public long RunGroup { get; set; }
    }

    public class LoadAgent
    {
        public string AgentIP { get; set; }
        public byte DeviceSet { get; set; }
        public int AmqpPoolSize { get; set; }
        public int ConnectPacePerSec { get; set; }
        public int ConnectIdleTimeout { get; set; }
        public string ControllerIP { get; set; }

        public TestRun CurrentRun { get; set; } = new TestRun(0, new DateTime());

        public bool InGrid { get; set; }

        public long MemoryUsage { get; set; }
        public int CPUUsagePercentage { get; set; }
    }
}
