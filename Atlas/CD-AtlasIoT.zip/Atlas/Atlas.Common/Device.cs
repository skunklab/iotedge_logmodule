﻿using Atlas.TimeSync.Client;
using Microsoft.Azure.Devices;
using Microsoft.Azure.Devices.Client;
//using Microsoft.Azure.EventHubs;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;

namespace Atlas.Common
{
    public class Device
    {
        public string DeviceId { get; private set; }
        public int NoOfMessages { get; private set; }
        private string DeviceKey { get; set; }
        private string IoTHub { get; set; }
        private int StartDelay { get; set; }

        public int AverageResponseTime { get; private set; }
        public int Percentile95ResponseTime { get; private set; }
        public int ExceptionsRecieved { get; private set; } = 0;

        public int NoOfMessagesSent { get; private set; } = 0;
        public long TotalPayloadSize { get; private set; } = 0;

        //ServiceClient serviceClient;
        DeviceClient deviceClient;
       // EventHubClient ehClient;
        IMessageProvider messageProvider;

        public static bool C2DMessage = false;
        public static bool SavePayLoad = false;
        public static bool RunEventHub = false;
        public static bool UseMQTT = true;
        public static int RunId;
        public static string AgentName;

        public static CancellationTokenSource StopTest = new CancellationTokenSource();
        public static TimeSyncClient TimeCli;

        static AmqpConnectionPoolSettings amqpConnectionPoolSettings;
        static ITransportSettings[] transportSettings;
        
        const string DeviceConnectionString = "HostName={2};DeviceId={0};SharedAccessKey={1}";
        public void Read(SqlDataReader sqlRdr, IMessageProvider MessageProvider)
        {
            messageProvider = MessageProvider;

            DeviceId = sqlRdr["DeviceId"].ToString();
            NoOfMessages = (int)sqlRdr["NoOfMessages"];
            DeviceKey = sqlRdr["DeviceKey"].ToString();
            IoTHub = sqlRdr["IoTHub"].ToString();
            StartDelay = (int)sqlRdr["StartDelay"];

            messageProvider.Setup(DeviceId, sqlRdr["DeviceConfig"] != DBNull.Value 
                ? sqlRdr["DeviceConfig"].ToString() : string.Empty,
                (int)sqlRdr["MessageDelay"]);
        }

        public static void SetAmqpPoolSettings(int poolsize, int connectIdleTimeout)
        {
            amqpConnectionPoolSettings = new AmqpConnectionPoolSettings
            { MaxPoolSize = unchecked((uint)poolsize), Pooling = true, ConnectionIdleTimeout = TimeSpan.FromSeconds(connectIdleTimeout) };

            transportSettings = new ITransportSettings[]
            {new AmqpTransportSettings(Microsoft.Azure.Devices.Client.TransportType.Amqp_Tcp_Only)
                         {AmqpConnectionPoolSettings= amqpConnectionPoolSettings},
            new AmqpTransportSettings(Microsoft.Azure.Devices.Client.TransportType.Amqp_WebSocket_Only)
                         {AmqpConnectionPoolSettings= amqpConnectionPoolSettings}
             };
        }

        CancellationTokenSource cancelToken = new CancellationTokenSource();
        public async Task ListenforC2D()
        {
            int commandIndex = 0;
            byte[] dataBuffer = null;

            Task.Run(async ()=>{ while (!cancelToken.IsCancellationRequested) {
                    Microsoft.Azure.Devices.Client.Message command = await deviceClient.ReceiveAsync(TimeSpan.FromSeconds(30)).ConfigureAwait(false);
                    if(command != null)
                    {
                        dataBuffer = SavePayLoad ? command.GetBytes() : null;
                        commands.Add(new CommandInfo(DeviceId, IoTHub, commandIndex++, TimeCli.AdjustedUtcDateTimeOffset.DateTime, 0, dataBuffer, TimeCli.TimeBroadcastQuality));
                        await deviceClient.CompleteAsync(command).ConfigureAwait(false);
                    }
                } }).ConfigureAwait(false);
        }

        public void CreateClient()
        {
            //if (RunEventHub)
            //    ehClient = EventHubClient.CreateFromConnectionString(ConfigurationManager.ConnectionStrings["EventHub"].ConnectionString);
            //else
            //{
            //    if (C2DMessage)
            //        serviceClient = ServiceClient.CreateFromConnectionString(ConfigurationManager.ConnectionStrings["C2DIoTHubConnStr"].ConnectionString);
            //    else

            if ((amqpConnectionPoolSettings.MaxPoolSize > 1) && !UseMQTT)
            {
                deviceClient = DeviceClient.CreateFromConnectionString(string.Format(DeviceConnectionString, DeviceId, DeviceKey,
            IoTHub), transportSettings);
            }
            else
                deviceClient = DeviceClient.CreateFromConnectionString(string.Format(DeviceConnectionString, DeviceId, DeviceKey,
                IoTHub), UseMQTT ? TransportType.Mqtt : TransportType.Amqp);
            cancelToken = new CancellationTokenSource();
            // }
        }

        public async Task DestroyClient()
        {
            //    if (RunEventHub)
            //        await ehClient.CloseAsync().ConfigureAwait(false);
            //    else
            //    {

            //        if (C2DMessage)
            //            await serviceClient.CloseAsync().ConfigureAwait(false);
            //        else
            cancelToken.Cancel();
                        await deviceClient.CloseAsync().ConfigureAwait(false);
            //}

            //serviceClient = null;
            deviceClient = null;
           // ehClient = null;
        }

        public async Task SendAllMessagesWReUseDevCli()
        {
            Stopwatch sw = new Stopwatch();
            DateTime dt = new DateTime();
            byte QoT = 0;
            byte[] dataBuffer;

            await Task.Delay(StartDelay * 1000, StopTest.Token).ConfigureAwait(false);

            for (int count = 0; count < NoOfMessages; count++)
            {
                dataBuffer = null;
                try
                {
                    if (StopTest.IsCancellationRequested)
                        break;
                    
                    sw = Stopwatch.StartNew();

                    //if (RunEventHub)
                    //{
                    //    EventData eventData = messageProvider.GetEventHubPayLoad(count);
                    //    dataBuffer = eventData.Body.Array;
                    //    TotalPayloadSize += eventData.Body.Count;
                    //    await ehClient.SendAsync(eventData);
                    //}
                    //else
                    //{
                    //    if (C2DMessage)
                    //    {
                    //        Microsoft.Azure.Devices.Message eventMessage = messageProvider.GetIoTHubC2DPayLoad(count);
                    //        await serviceClient.SendAsync(DeviceId, eventMessage).ConfigureAwait(false);
                    //        dataBuffer = new byte[0]; //eventMessage.GetBodyStream().re();
                    //    }
                    //    else
                    //    {
                            Microsoft.Azure.Devices.Client.Message eventMessage = messageProvider.GetIoTHubPayLoad(count);

                    dataBuffer = eventMessage.GetBytes();

                    eventMessage.Properties.Add("RunId", RunId.ToString());
                    eventMessage.Properties.Add("AgentName", AgentName);
                    eventMessage.Properties.Add("DeviceId", DeviceId);
                    eventMessage.Properties.Add("IoTHub", IoTHub);
                    eventMessage.Properties.Add("MessageIndex", count.ToString());

                    dt = TimeCli.AdjustedUtcDateTimeOffset.DateTime;
                    QoT = TimeCli.TimeBroadcastQuality;

                    eventMessage.Properties.Add("SimulatorTime", dt.ToString("yyyy-MM-ddTHH:mm:ss.fff"));
                    eventMessage.Properties.Add("SimulatorQoT", QoT.ToString());
                    await deviceClient.SendEventAsync(eventMessage).ConfigureAwait(false);
                        //}
                        TotalPayloadSize += dataBuffer.Length;
                    //}
                    sw.Stop();
                    messages.Add(new MessageInfo(DeviceId, IoTHub, count, dt, (int)sw.ElapsedMilliseconds, SavePayLoad ? dataBuffer : null, QoT));
                    NoOfMessagesSent++;
                }
                catch (Exception ex)
                {
                    sw.Stop();
                    ExceptionsRecieved++;
                    exceptions.Add(new ExceptionInfo(DeviceId, IoTHub, count, ex.GetType().Name, ex.Message,
                        dt, (int)sw.ElapsedMilliseconds, SavePayLoad ? dataBuffer : null, QoT));
                }

                try
                {
                    await messageProvider.WaitForNextMessage((int)sw.ElapsedMilliseconds, count, StopTest.Token).ConfigureAwait(false);
                }
                catch (Exception exa)
                {
                    Console.WriteLine("SendAllMessagesWReUseDevCli - " + exa.Message);
                }
            }
        }

        private List<MessageInfo> messages = new List<MessageInfo>();
        private List<CommandInfo> commands = new List<CommandInfo>();
        private List<ExceptionInfo> exceptions = new List<ExceptionInfo>();
        private List<MessageInfo> messagesA = new List<MessageInfo>();
        private List<CommandInfo> commandsA = new List<CommandInfo>();
        private List<ExceptionInfo> exceptionsA = new List<ExceptionInfo>();
        private List<MessageInfo> tMessages;
        private List<ExceptionInfo> tExceptions;
        private List<CommandInfo> tCommands;

        public bool Persist(List<MessageInfo> Messages, List<ExceptionInfo> Exceptions, List<CommandInfo> Commands)
        {
            if ((messages.Count == 0) && (exceptions.Count == 0) && (commands.Count == 0))
                return false;

            if (messages.Count > 0)
            {
                tMessages = messages;
                messages = messagesA;
                Messages.AddRange(tMessages);
                messagesA = tMessages;
                messagesA.Clear();
            }

            if (exceptions.Count > 0)
            {
                tExceptions = exceptions;
                exceptions = exceptionsA;
                Exceptions.AddRange(tExceptions);
                exceptionsA = tExceptions;
                exceptionsA.Clear();
            }

            if (commands.Count > 0)
            {
                tCommands = commands;
                commands = commandsA;
                Commands.AddRange(tCommands);
                commandsA = tCommands;
                commandsA.Clear();
            }

            return true;
        }
    }
}
