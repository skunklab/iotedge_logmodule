﻿using Microsoft.Azure.Devices.Client;
//using Microsoft.Azure.EventHubs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Atlas.Common
{

    public abstract class IMessageProvider
    {
        protected string DeviceId { get; set; }
        protected string ConfigData { get; set; }
        protected int MessageDelay { get; set; }
        public virtual void Setup(string DeviceId, string ConfigData, int MessageDelay)
        {
            this.DeviceId = DeviceId;
            this.ConfigData = ConfigData;
            this.MessageDelay = MessageDelay;
        }

        int RemainingMessageDelay;
        public virtual async Task WaitForNextMessage(int TimeSpentOnOtherThings, int MessageIndex, CancellationToken StopTest)
        {
            RemainingMessageDelay = (MessageDelay * 1000) - TimeSpentOnOtherThings;
            if (RemainingMessageDelay > 0)
                await Task.Delay(RemainingMessageDelay, StopTest).ConfigureAwait(false);
        }

        //public abstract Microsoft.Azure.Devices.Message GetIoTHubC2DPayLoad(int MessageIndex);
        public abstract Message GetIoTHubPayLoad(int MessageIndex);
        //public abstract EventData GetEventHubPayLoad(int MessageIndex);
    }
}
