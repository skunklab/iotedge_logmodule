﻿using Atlas.Common;
using Atlas.TimeSync.Client;
using Atlas.TimeSync.Client.Tcp;
//using Microsoft.Azure.Amqp.Transport;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Atlas.IoT
{
    public class LoadEngine
    {
        LoadAgent AgentState = new LoadAgent();
        Stopwatch TestTimer;
        string sqlConnectionString;
        SqlConnection sqlConnTest;
        SqlConnection sqlConnState;
        List<Device> TestTCUs = null;

        public LoadEngine()
        {
            sqlConnectionString = ConfigurationManager.ConnectionStrings["AtlasDB"].ConnectionString;
            sqlConnTest = new SqlConnection(sqlConnectionString);
            sqlConnState = new SqlConnection(sqlConnectionString);

            sqlConnTest.OpenAsync().Wait();
            sqlConnState.OpenAsync().Wait();

            ReadAgent(sqlConnTest);
        }

        private void ReadAgent(SqlConnection sqlConn)
        {
            SqlCommand sqlCmd = new SqlCommand("spGetAgent", sqlConn);
            sqlCmd.CommandType = System.Data.CommandType.StoredProcedure;
            sqlCmd.CommandTimeout = 180000;
            AgentState.AgentIP = Dns.GetHostName();
            sqlCmd.Parameters.AddWithValue("@AgentName", AgentState.AgentIP);

            SqlDataReader sqlRdr = sqlCmd.ExecuteReader();
            if (sqlRdr.Read())
            {
                AgentState.AmqpPoolSize = (int)sqlRdr["AmqpPoolSize"];
                AgentState.DeviceSet = (byte)sqlRdr["DeviceSet"];
                AgentState.AmqpPoolSize = (int)sqlRdr["AmqpPoolSize"];
                AgentState.ConnectPacePerSec = (int)sqlRdr["ConnectPacePerSec"];
                AgentState.ConnectIdleTimeout = (int)sqlRdr["ConnectIdleTimeoutInSec"];
                AgentState.ControllerIP = sqlRdr["ControllerIP"].ToString();
                AgentState.CurrentRun.RunState = TestRunStatus.Ready;
                AgentState.CurrentRun.TotalDevices = (int)sqlRdr["NoOfDevices"];
                AgentState.CurrentRun.TotalMessages = (int)sqlRdr["NoofMessages"];

                Console.WriteLine("Agent Authorized ...");
            }
            else
                throw new Exception("Agent Not Authorized!");
            sqlRdr.Close();
        }

        private async Task SaveTestRunAsync(SqlConnection sqlConn, bool IsAborted)
        {
            SqlCommand sqlCmd = new SqlCommand("spUpdateTestRun", sqlConn);
            sqlCmd.CommandType = System.Data.CommandType.StoredProcedure;
            sqlCmd.CommandTimeout = 180000;
            sqlCmd.Parameters.AddWithValue("@RunId", AgentState.CurrentRun.RunId);
            sqlCmd.Parameters.AddWithValue("@MessagesSent", AgentState.CurrentRun.MessagesSent);
            sqlCmd.Parameters.AddWithValue("@ExceptionsRecieved", AgentState.CurrentRun.ExceptionsRecieved);
            sqlCmd.Parameters.AddWithValue("@Throughput", AgentState.CurrentRun.MessagesPerMinute);
            sqlCmd.Parameters.AddWithValue("@AverageResponseTime", AgentState.CurrentRun.AverageResponseTimeInMS);
            sqlCmd.Parameters.AddWithValue("@Percentile95ResponseTime", AgentState.CurrentRun.Percentile95ResponseTimeInMS);
            sqlCmd.Parameters.AddWithValue("@EndTime", AgentState.CurrentRun.TestEnd);
            sqlCmd.Parameters.AddWithValue("@IsAborted", IsAborted);

            await sqlCmd.ExecuteNonQueryAsync().ConfigureAwait(false);
        }

        private async Task StartTestRunAsync(SqlConnection sqlConn)
        {
            SqlCommand sqlCmd = new SqlCommand("spAddTestRun", sqlConn);
            sqlCmd.CommandType = System.Data.CommandType.StoredProcedure;
            sqlCmd.CommandTimeout = 180000;
            sqlCmd.Parameters.AddWithValue("@AgentName", AgentState.AgentIP);
            sqlCmd.Parameters.AddWithValue("@TotalDevices", AgentState.CurrentRun.TotalDevices);
            sqlCmd.Parameters.AddWithValue("@TotalMessages", AgentState.CurrentRun.TotalMessages);
            sqlCmd.Parameters.AddWithValue("@DeviceConnectTime", AgentState.CurrentRun.DeviceConnectTime);
            sqlCmd.Parameters.AddWithValue("@StartTime", AgentState.CurrentRun.TestStart);
            sqlCmd.Parameters.AddWithValue("@RunGroup", AgentState.CurrentRun.RunGroup);

            AgentState.CurrentRun.RunId = (int)await sqlCmd.ExecuteScalarAsync().ConfigureAwait(false);
        }

        private List<Device> ReadTCUs(SqlConnection sqlConn, byte DeviceSet, Type IMessageProviderType)
        {
            SqlCommand sqlCmd = new SqlCommand("spGetDeviceSet", sqlConn);
            sqlCmd.CommandType = System.Data.CommandType.StoredProcedure;
            sqlCmd.CommandTimeout = 180000;
            sqlCmd.Parameters.AddWithValue("@DeviceSet", DeviceSet);

            SqlDataReader sqlRdr = sqlCmd.ExecuteReader();
            List<Device> tcus = new List<Device>();
            while (sqlRdr.Read())
            {
                Device tcu = new Device();
                tcu.Read(sqlRdr, (IMessageProvider)Activator.CreateInstance(IMessageProviderType));
                tcus.Add(tcu);
            }
            sqlRdr.Close();

            return tcus;
        }

        private LoadAgent GetAtlasCommand(RestClient client)
        {
            try
            {
                var request = new RestRequest("Atlas/api/Atlas");
                request.AddQueryParameter("AgentName", AgentState.AgentIP);
                request.Method = Method.GET;
                IRestResponse resp = client.Execute(request);

                dynamic obj = JsonConvert.DeserializeObject<LoadAgent>(resp.Content);
                request = null;
                resp = null;

                return obj;
            }
            catch (Exception ex)
            {
                Console.WriteLine("GetAtlasCommand - " + ex.Message);
            }
            return null;
        }

        private void SendTestStatus(RestClient client)
        {
            try
            {
                var request = new RestRequest("Atlas/api/Atlas");
                request.Method = Method.POST;
                request.AddJsonBody(AgentState);
                IRestResponse resp = client.Execute(request);
                request = null;
                resp = null;
            }
            catch (Exception ex)
            {
                Console.WriteLine("SendTestStatus - " + ex.Message);
            }
        }
        TimeSyncClient timesync;
        public async Task StartAsync()
        {
            try
            {
                Console.WriteLine("Starting time sync client!");
                timesync = new TimeSyncClient(new TcpTimeBroadcastListener(new IPEndPoint(IPAddress.Parse(AgentState.ControllerIP), 8463)));
                timesync.Start();
                while (timesync.TimeBroadcastQuality != 2)
                {
                    await Task.Delay(2000).ConfigureAwait(false);
                    Console.WriteLine("Waiting for good time sync signal!");
                }
                Device.TimeCli = timesync;


                var MessageProviderLib = Assembly.Load(ConfigurationManager.AppSettings["MessageProviderLib"]);
                Type MessageProviderType = MessageProviderLib.GetType(ConfigurationManager.AppSettings["MessageProvider"]);

                new Task(async () => { await StateUpdateAsync().ConfigureAwait(false); }).Start();

                while ((AgentState.CurrentRun.RunState != TestRunStatus.ShutdownInitiated))
                {
                    try
                    {
                        if (AgentState.CurrentRun.RunState == TestRunStatus.RunInitiated)
                        {
                            AgentState.CurrentRun = new TestRun(AgentState.CurrentRun.RunGroup, AgentState.CurrentRun.StartTestAt);
                            AgentState.CurrentRun.RunState = TestRunStatus.AgentWarmingUp;

                            if ((sqlConnTest.State == ConnectionState.Closed) || (sqlConnTest.State == ConnectionState.Broken))
                                await sqlConnTest.OpenAsync().ConfigureAwait(false);

                            ReadAgent(sqlConnTest);
                            AgentState.CurrentRun.RunState = TestRunStatus.AgentWarmingUp;

                            TestTCUs = ReadTCUs(sqlConnTest, AgentState.DeviceSet, MessageProviderType);
                            Device.SetAmqpPoolSettings(AgentState.AmqpPoolSize, AgentState.ConnectIdleTimeout);

                            AgentState.CurrentRun.TotalMessages = 0;
                            TestTimer = Stopwatch.StartNew();
                            foreach (Device tcu in TestTCUs)
                            {
                                AgentState.CurrentRun.TotalMessages += tcu.NoOfMessages;
                                tcu.CreateClient();
                            }
                            Console.WriteLine("Starting to listen all!");

                            for (int i = 0; i <= TestTCUs.Count / AgentState.ConnectPacePerSec; i++)
                            {
                                if (TestTCUs.Count > AgentState.ConnectPacePerSec * i)
                                {
                                    int ubound = AgentState.ConnectPacePerSec * i + AgentState.ConnectPacePerSec > TestTCUs.Count ? TestTCUs.Count - AgentState.ConnectPacePerSec * i : AgentState.ConnectPacePerSec;
                                    await Task.WhenAll(TestTCUs.GetRange(AgentState.ConnectPacePerSec * i, ubound).Select(k => k.ListenforC2D())).ConfigureAwait(false);
                                    Console.WriteLine("Initiated Listen for - {0} to {1}", AgentState.ConnectPacePerSec * i, AgentState.ConnectPacePerSec * i + AgentState.ConnectPacePerSec);
                                    await Task.Delay(1000).ConfigureAwait(false);
                                }
                            }
                            TestTimer.Stop();
                            Console.WriteLine("Device Client Creation Time - {0}ms for {1} TCUs", TestTimer.ElapsedMilliseconds, TestTCUs.Count);

                            AgentState.CurrentRun.DeviceConnectTime = TestTimer.ElapsedMilliseconds;
                            AgentState.CurrentRun.TotalDevices = TestTCUs.LongCount<Device>();

                            while (DateTime.UtcNow < AgentState.CurrentRun.StartTestAt)
                                await Task.Delay(500).ConfigureAwait(false);

                            AgentState.CurrentRun.TestStart = DateTime.UtcNow;
                            await StartTestRunAsync(sqlConnTest).ConfigureAwait(false);
                            AgentState.CurrentRun.RunState = TestRunStatus.TestStarted;

                            Device.RunId = CommandInfo.CurrentRunId = MessageInfo.CurrentRunId = ExceptionInfo.CurrentRunId = AgentState.CurrentRun.RunId;
                            Device.AgentName = CommandInfo.CurrentAgentName = MessageInfo.CurrentAgentName = ExceptionInfo.CurrentAgentName = AgentState.AgentIP;

                            TestTimer = Stopwatch.StartNew();
                            await SendAllMessagesWReUseDevCli(TestTCUs);
                            TestTimer.Stop();
                            AgentState.CurrentRun.TestEnd = DateTime.UtcNow;

                            AgentState.CurrentRun.MessagesSent = 0;
                            AgentState.CurrentRun.ExceptionsRecieved = 0;
                            AgentState.CurrentRun.TotalPayloadSizeInBytes = 0;
                            foreach (Device tcu in TestTCUs)
                            {
                                AgentState.CurrentRun.MessagesSent += tcu.NoOfMessagesSent;
                                AgentState.CurrentRun.ExceptionsRecieved += tcu.ExceptionsRecieved;
                                AgentState.CurrentRun.TotalPayloadSizeInBytes += tcu.TotalPayloadSize;
                                await tcu.DestroyClient().ConfigureAwait(false);
                            }
                            //for (int i = 0; i < TcpTransportInitiator.LocalPortList.Length; i++)
                            //    TcpTransportInitiator.LocalPortList[i] = 10000;
                            AgentState.CurrentRun.MessagesPerMinute = (int)(AgentState.CurrentRun.MessagesSent / TestTimer.Elapsed.TotalMinutes);
                            AgentState.CurrentRun.MBPerMinute = (decimal)(AgentState.CurrentRun.TotalPayloadSizeInBytes / TestTimer.Elapsed.TotalMinutes) / (1024m * 1024m);
                            AgentState.CurrentRun.RunState = TestRunStatus.TestCompleted;

                            Console.WriteLine("\nTest Completed.");
                            Console.WriteLine("Start Time - {0}", AgentState.CurrentRun.TestStart.ToString("ddMMMyy HH:mm:ss.fff"));
                            Console.WriteLine("End Time - {0}", AgentState.CurrentRun.TestEnd.ToString("ddMMMyy HH:mm:ss.fff"));
                            Console.WriteLine("Total Messages To Sent - {0}", AgentState.CurrentRun.TotalMessages);
                            Console.WriteLine("Total Messages Sent - {0}", AgentState.CurrentRun.MessagesSent);
                            Console.WriteLine("Total Exceptions Recieved - {0}", AgentState.CurrentRun.ExceptionsRecieved);
                            Console.WriteLine("Time Elapsed - {0}", TestTimer.Elapsed.ToString());
                            Console.WriteLine("Throughput - {0} msg/min", AgentState.CurrentRun.MessagesPerMinute);
                            Console.WriteLine("Sustained Data Rate - {0:0.000} MB/min", AgentState.CurrentRun.MBPerMinute);

                            await SaveTestRunAsync(sqlConnTest, ((AgentState.CurrentRun.MessagesSent + AgentState.CurrentRun.ExceptionsRecieved) < AgentState.CurrentRun.TotalMessages));
                        }
                        else
                            await Task.Delay(5000).ConfigureAwait(false);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("StartAsync1 - " + ex.Message);
                    }
                }

                AgentState.CurrentRun.RunState = TestRunStatus.TestShutdown;
            }
            catch (Exception ex)
            {
                Console.WriteLine("StartAsync2 - " + ex.Message);
            }
        }


        List<ExceptionInfo> exceptions = new List<ExceptionInfo>();
        List<MessageInfo> messages = new List<MessageInfo>();
        List<CommandInfo> commands = new List<CommandInfo>();
        bool somethingtopersist = false;
        SqlBulkCopy sbCopy;

        private async Task StateUpdateAsync()
        {
            PerformanceCounter cpuCounter = new PerformanceCounter("Processor", "% Processor Time", "_Total");
            RestClient client = new RestClient();
            client.BaseUrl = new Uri("http://" + AgentState.ControllerIP + ":1234/");
            client.FollowRedirects = true;
            sbCopy = new SqlBulkCopy(sqlConnState);
            sbCopy.BulkCopyTimeout = 0;
            sbCopy.BatchSize = 10000;

            while ((AgentState.CurrentRun.RunState != TestRunStatus.ShutdownInitiated) && (AgentState.CurrentRun.RunState != TestRunStatus.TestShutdown))
            {
                try
                {
                    LoadAgent csd = GetAtlasCommand(client);
                    if (csd != null)
                    {
                        if ((csd.CurrentRun.RunState == TestRunStatus.RunInitiated) && (
                            (AgentState.CurrentRun.RunState == TestRunStatus.Ready) || (AgentState.CurrentRun.RunState == TestRunStatus.TestStopped)
                            || (AgentState.CurrentRun.RunState == TestRunStatus.TestCompleted)))
                        {
                            AgentState.CurrentRun.RunState = TestRunStatus.RunInitiated;
                            AgentState.CurrentRun.StartTestAt = csd.CurrentRun.StartTestAt;
                            AgentState.CurrentRun.RunGroup = csd.CurrentRun.RunGroup;
                            Device.StopTest = new CancellationTokenSource();
                        }
                        else if (csd.CurrentRun.RunState == TestRunStatus.StopRequested)
                        {
                            AgentState.CurrentRun.RunState = TestRunStatus.AgentRampingDown;
                            Device.StopTest.CancelAfter(100);
                        }

                        csd = null;
                    }

                    if (TestTCUs != null)
                    {
                        AgentState.CurrentRun.MessagesSent = 0;
                        AgentState.CurrentRun.ExceptionsRecieved = 0;
                        AgentState.CurrentRun.TotalPayloadSizeInBytes = 0;

                        exceptions.Clear();
                        messages.Clear();
                        commands.Clear();
                        somethingtopersist = false;
                        foreach (Device tcu in TestTCUs)
                        {
                            AgentState.CurrentRun.MessagesSent += tcu.NoOfMessagesSent;
                            AgentState.CurrentRun.ExceptionsRecieved += tcu.ExceptionsRecieved;
                            AgentState.CurrentRun.TotalPayloadSizeInBytes += tcu.TotalPayloadSize;
                            somethingtopersist |= tcu.Persist(messages, exceptions, commands);
                        }

                        if (somethingtopersist)
                        {
                            if ((sqlConnState.State == ConnectionState.Closed) || (sqlConnState.State == ConnectionState.Broken))
                            {
                                await sqlConnState.OpenAsync().ConfigureAwait(false);
                                sbCopy = new SqlBulkCopy(sqlConnState);
                                sbCopy.BulkCopyTimeout = 0;
                                sbCopy.BatchSize = 10000;
                            }
                            sbCopy.DestinationTableName = "Exceptions";
                            sbCopy.WriteToServer(exceptions.AsDataTable());

                            sbCopy.DestinationTableName = "Messages";
                            sbCopy.WriteToServer(messages.AsDataTable());

                            sbCopy.DestinationTableName = "Commands";
                            sbCopy.WriteToServer(commands.AsDataTable());
                        }

                        if ((TestTimer != null) && (TestTimer.Elapsed.TotalMinutes > 0))
                        {
                            AgentState.CurrentRun.MessagesPerMinute = (int)(AgentState.CurrentRun.MessagesSent / TestTimer.Elapsed.TotalMinutes);
                            AgentState.CurrentRun.MBPerMinute = (decimal)(AgentState.CurrentRun.TotalPayloadSizeInBytes / TestTimer.Elapsed.TotalMinutes) / (1024m * 1024m);
                        }
                        else
                        {
                            AgentState.CurrentRun.MessagesPerMinute = 0;
                            AgentState.CurrentRun.MBPerMinute = 0;
                        }

                        Console.WriteLine("Throughput = {0} msg(s)/min", AgentState.CurrentRun.MessagesPerMinute);
                        Console.WriteLine("Data Rate = {0:0.000} MB/min", AgentState.CurrentRun.MBPerMinute);
                        Console.WriteLine("Total Messages Sent = {0}", AgentState.CurrentRun.MessagesSent);
                        Console.WriteLine("Total Exceptions Recieved = {0}", AgentState.CurrentRun.ExceptionsRecieved);
                        Console.WriteLine("Percentage Test Completion = {0:d}%", (AgentState.CurrentRun.MessagesSent + AgentState.CurrentRun.ExceptionsRecieved) * 100 / AgentState.CurrentRun.TotalMessages);

                        if (AgentState.CurrentRun.RunState == TestRunStatus.TestCompleted)
                        {
                            TestTCUs = null;
                            if ((AgentState.CurrentRun.MessagesSent + AgentState.CurrentRun.ExceptionsRecieved) < AgentState.CurrentRun.TotalMessages)
                                AgentState.CurrentRun.RunState = TestRunStatus.TestStopped;
                        }
                    }

                    AgentState.MemoryUsage = Process.GetCurrentProcess().PrivateMemorySize64 / (1024 * 1024);
                    AgentState.CPUUsagePercentage = (int)cpuCounter.NextValue();

                    SendTestStatus(client);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("StateUpdateAsync - " + ex.Message);
                }
                await Task.Delay(5000).ConfigureAwait(false);
            }

            AgentState.CurrentRun.RunState = TestRunStatus.AgentShutDown;
            SendTestStatus(client);
        }

        private static Task SendAllMessagesWReUseDevCli(List<Device> tcus)
        { return Task.WhenAll(tcus.Select(k => k.SendAllMessagesWReUseDevCli())); }

    }
}
