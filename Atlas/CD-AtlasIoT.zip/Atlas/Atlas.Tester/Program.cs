﻿using Atlas.Common;
using System;
using System.Configuration;

namespace Atlas.IoT
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Atlas Load Test Agent Initializing ...");

            Device.RunEventHub = (ConfigurationManager.AppSettings["RunEventHub"] == "1");
            Device.SavePayLoad = (ConfigurationManager.AppSettings["SavePayLoad"] == "1");
            Device.C2DMessage = (ConfigurationManager.AppSettings["C2DMessage"] == "1");
            Device.UseMQTT = (ConfigurationManager.AppSettings["UseMQTT"] == "1");

            LoadEngine lg = new LoadEngine();
            lg.StartAsync().Wait();
        }
    }
}
