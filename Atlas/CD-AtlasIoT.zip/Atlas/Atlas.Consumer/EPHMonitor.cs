﻿using Atlas.TimeSync.Client;
using Atlas.TimeSync.Client.Tcp;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Atlas.IoT
{
    class EPHMonitor
    {
        public static EPHComponent[] EPHs = new EPHComponent[100];
        public static string sqlConnectionString = ConfigurationManager.ConnectionStrings["LogDB"].ConnectionString;
        public static string ControllerIP = ConfigurationManager.AppSettings["ControllerIP"];

        public static TimeSyncClient TimeCli = new TimeSyncClient(new TcpTimeBroadcastListener(new IPEndPoint(IPAddress.Parse(ControllerIP), 8463)));

        public async Task StartAsync()
        {
            SqlConnection sqlConn = new SqlConnection(sqlConnectionString);
            await sqlConn.OpenAsync().ConfigureAwait(false);
            SqlBulkCopy sbCopy = new SqlBulkCopy(sqlConn);
            sbCopy.BulkCopyTimeout = 0;
            sbCopy.BatchSize = 10000;
            sbCopy.DestinationTableName = "EPHMessages";

            try
            {
                while (true)
                {
                    try
                    {
                        long totalMsg = 0;
                        DateTime firstMsg = DateTime.UtcNow;
                        DateTime lastMsg = new DateTime();

                        for (int i = EPHs.Length - 1; i >= 0; i--)
                        {
                            EPHComponent ephCmp = EPHs[i];
                            if (ephCmp != null)
                            {
                                totalMsg += ephCmp.MessageCount;
                                if (ephCmp.FirstMessage < firstMsg)
                                    firstMsg = ephCmp.FirstMessage;

                                if (ephCmp.LastMessage > lastMsg)
                                    lastMsg = ephCmp.LastMessage;



                                if ((sqlConn.State == ConnectionState.Closed) || (sqlConn.State == ConnectionState.Broken))
                                {
                                    await sqlConn.OpenAsync().ConfigureAwait(false);
                                    sbCopy = new SqlBulkCopy(sqlConn);
                                    sbCopy.BulkCopyTimeout = 0;
                                    sbCopy.BatchSize = 10000;
                                    sbCopy.DestinationTableName = "LogTimes";
                                }
                                await ephCmp.PersistAsync(sbCopy).ConfigureAwait(false);
                            }
                        }

                        long totmins = (long)lastMsg.Subtract(firstMsg).TotalSeconds;

                        if (totmins > 0)
                            Console.WriteLine("Total Messages = {0}; Throughput = {1:###,##0} msgs/min", totalMsg,
                                totalMsg * 60 / totmins);
                        await Task.Delay(5000).ConfigureAwait(false);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("StartAsync1 - " + ex.Message);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("StartAsync2 - " + ex.Message);
            }

            sqlConn.Close();
        }
    }
}
