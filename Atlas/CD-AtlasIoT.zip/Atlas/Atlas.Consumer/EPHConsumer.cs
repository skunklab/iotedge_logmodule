﻿using Microsoft.ServiceBus.Messaging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atlas.IoT
{
    class EPHConsumer : IEventProcessor
    {
        public static bool PrintPayload { get; set; } = false;
        public async Task CloseAsync(PartitionContext context, CloseReason reason)
        {
            if (reason == CloseReason.Shutdown)
            {
                await context.CheckpointAsync();
            }

            Console.WriteLine($"Stopped listening on Parition - {context.Lease.PartitionId}");
        }

        public Task OpenAsync(PartitionContext context)
        {
            Console.WriteLine($"Started listening on Parition - {context.Lease.PartitionId}");
            EPHMonitor.EPHs[int.Parse(context.Lease.PartitionId)] = new EPHComponent(context);

            return Task.FromResult<object>(null);
        }

        static DateTime BLANKDATE = new DateTime();
        private DateTime GetLogTime(string str, out string instance, out byte level)
        {
            DateTime dt = BLANKDATE;
            instance = string.Empty;
            level = 255;

            try
            {
                int startIndx = str.IndexOf("\"time\":\"");
                int len;

                if (startIndx >= 0)
                {
                    startIndx += 8;
                    len = str.IndexOf(",", startIndx) - startIndx - 1;
                    if (len >= 0)
                        DateTime.TryParse(str.Substring(startIndx, len), out dt);
                }
                else
                {
                    startIndx = str.IndexOf("\"Timestamp\":\"");
                    if (startIndx >= 0)
                    {
                        startIndx += 13;
                        len = str.IndexOf(",", startIndx) - startIndx - 1;
                        if (len >= 0)
                            DateTime.TryParse(str.Substring(startIndx, len), out dt);
                    }
                }

                startIndx = startIndx < 0 ? 0 : startIndx;
                startIndx = str.IndexOf("\"RoleInstance\":\"", startIndx);
                if (startIndx >= 0)
                {
                    startIndx += 16;
                    len = str.IndexOf(",", startIndx) - startIndx - 1;
                    if (len >= 0)
                        instance = str.Substring(startIndx, len);
                }

                startIndx = startIndx < 0 ? 0 : startIndx;
                startIndx = str.IndexOf("\"Level\":", startIndx);
                if (startIndx >= 0)
                {
                    startIndx += 8;
                    len = str.IndexOf(",", startIndx) - startIndx;
                    if (len >= 0)
                        byte.TryParse(str.Substring(startIndx, len), out level);
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return dt;
        }

        public async Task ProcessEventsAsync(PartitionContext context, IEnumerable<EventData> messages)
        {
            DateTime EPHTime = EPHMonitor.TimeCli.AdjustedUtcDateTimeOffset.DateTime;
            byte QoT = EPHMonitor.TimeCli.TimeBroadcastQuality;

            try
            {
                await context.CheckpointAsync().ConfigureAwait(false);

                EPHComponent ephCmp = EPHMonitor.EPHs[int.Parse(context.Lease.PartitionId)];

                if (PrintPayload)
                {
                    foreach (EventData msg in messages)
                    {
                        int RunId = int.Parse((string)msg.Properties["RunId"]);
                        string DeviceId = (string)msg.Properties["DeviceId"];
                        string AgentName = (string)msg.Properties["AgentName"];
                        string IoTHub = (string)msg.Properties["IoTHub"];
                        DateTime SimulatorTime = DateTime.Parse((string)msg.Properties["SimulatorTime"]);
                        byte SimulatorQoT = byte.Parse((string)msg.Properties["SimulatorQoT"]);
                        int MessageIndex = int.Parse((string)msg.Properties["MessageIndex"]);
                        Guid Identifier = Guid.Parse((string)msg.Properties["Identifier"]);
                        DateTime EnqueueTime = msg.EnqueuedTimeUtc;

                        ephCmp.AddMessage(Identifier, RunId, AgentName, DeviceId, IoTHub, MessageIndex, SimulatorTime, SimulatorQoT, EnqueueTime, EPHTime, QoT);
                    }
                }
                ephCmp.AddMessageCount(messages.LongCount());
                //await Task.Delay(10).ConfigureAwait(false);
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
