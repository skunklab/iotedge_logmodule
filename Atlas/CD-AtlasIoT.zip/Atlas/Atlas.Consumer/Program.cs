﻿using Microsoft.ServiceBus.Messaging;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atlas.IoT
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Atlas Event Hub Consumer using EPH!");
            if (args.Length >= 4)
            {
                var eventHubPath = ConfigurationManager.AppSettings["EventHubPath"];
                var consumerGroupName = ConfigurationManager.AppSettings["ConsumerGroupName"];
                var eventHubConnectionString = ConfigurationManager.AppSettings["EventHubConnectionString"];
                var storageConnectionString = ConfigurationManager.AppSettings["StorageConnectionString"];
                var eph = new EventProcessorHost(eventHubPath, consumerGroupName, eventHubConnectionString, storageConnectionString);
                EPHMonitor ephmon = new EPHMonitor();
                EPHMonitor.TimeCli.Start();
                while (EPHMonitor.TimeCli.TimeBroadcastQuality != 2)
                {
                    Task.Delay(2000).Wait();
                    Console.WriteLine("Waiting for good time sync signal!");
                }

                EPHConsumer.PrintPayload = (int.Parse(args[3]) == 1);

                Console.WriteLine("Starting event processor host.");
                EventProcessorOptions ephopt = new EventProcessorOptions() { PrefetchCount = int.Parse(args[0]),
                    MaxBatchSize = int.Parse(args[1]), ReceiveTimeOut = TimeSpan.FromSeconds(int.Parse(args[2])) };
                eph.RegisterEventProcessorAsync<EPHConsumer>(ephopt).GetAwaiter().GetResult();

                ephmon.StartAsync().Wait();

                //eph.UnregisterEventProcessorAsync().GetAwaiter().GetResult();
            }
            else
            {
                Console.WriteLine("Usage: AtlasConsumer.exe <PrefetchCount> <MaxBatchSize> <ReceiveTimeOutInSec> <PrintPayload-0|1>");
                Console.WriteLine("eg: AtlasConsumer.exe 1000 1000 30 0");
            }
        }

        private void EventProcessor_ExceptionReceived(object sender, ExceptionReceivedEventArgs e)
        {
            Console.WriteLine($"Error occured in event processor. \n {e.Exception}");
        }
    }
}
