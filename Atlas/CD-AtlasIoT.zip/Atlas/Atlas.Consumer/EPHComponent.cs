﻿using Microsoft.ServiceBus.Messaging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atlas.IoT
{
    public class EPHComponent
    {
        DataTable TableA;
        DataTable TableB;

        private DataTable GetEPHMessageTable()
        {
            DataTable TableA = new DataTable("EPHMessages");

            TableA.Columns.Add("Identifier", typeof(Guid));
            TableA.Columns.Add("RunId", typeof(int));
            TableA.Columns.Add("AgentName", typeof(string));
            TableA.Columns.Add("DeviceId", typeof(string));
            TableA.Columns.Add("IotHub", typeof(string));
            TableA.Columns.Add("MessageIndex", typeof(int));
            TableA.Columns.Add("SimulatorTime", typeof(DateTime));
            TableA.Columns.Add("SimulatorQoT", typeof(byte));
            TableA.Columns.Add("EnqueTime", typeof(DateTime));
            TableA.Columns.Add("EPHTime", typeof(DateTime));
            TableA.Columns.Add("QoT", typeof(byte));            

            return TableA;
        }

        public EPHComponent(PartitionContext Context)
        {
            this.Context = Context;
            FirstMessage = DateTime.UtcNow;
            LastMessage = DateTime.UtcNow;

            TableA = GetEPHMessageTable();

            TableB = GetEPHMessageTable();
        }
        public PartitionContext Context { get; private set; }

        public DateTime FirstMessage { get; private set; }
        public DateTime LastMessage { get; private set; }

        public long MessageCount { get; private set; } = 0;

        public void AddMessageCount(long Messages)
        {
            if (MessageCount == 0)
                FirstMessage = DateTime.UtcNow;

            MessageCount += Messages;
            LastMessage = DateTime.UtcNow;
        }

        public void AddMessage(Guid Identifier, int RunId, string AgentName, string DeviceId, string IoTHub, int MessageIndex, DateTime SimulatorTime, byte SimulatorQoT, DateTime EnqueTime, DateTime EPHTime, byte QoT)
        {
            TableA.Rows.Add(Identifier, RunId, AgentName, DeviceId, IoTHub, MessageIndex, SimulatorTime, SimulatorQoT, EnqueTime, EPHTime, QoT);
        }

        public async Task PersistAsync(SqlBulkCopy SbCopy)
        {
            try
            {
                if (TableA.Rows.Count > 0)
                {
                    DataTable tTable = TableA;
                    TableA = TableB;
                    TableB = tTable;

                    await Task.Delay(10).ConfigureAwait(false);
                    await SbCopy.WriteToServerAsync(TableB).ConfigureAwait(false);
                    TableB.Rows.Clear();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("PersistAsync - " + ex.Message);
            }
        }
    }
}
