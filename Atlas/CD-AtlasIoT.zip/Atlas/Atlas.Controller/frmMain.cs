﻿using Atlas.Common;
using Atlas.TimeSync.Server;
using Atlas.TimeSync.Server.Tcp;
using Microsoft.Owin.Hosting;
using System;
using System.Diagnostics;
using System.Linq;
using System.Windows.Forms;

namespace Atlas.IoT
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void cmdStartTest_Click(object sender, EventArgs e)
        {
            if (AtlasController.Agents.Count > 0)
            {
                stopRequested = false;
                cmdStartTest.Enabled = false;
                cmdStopTest.Enabled = true;
                DateTime startAt = DateTime.UtcNow.AddSeconds(10);
                long RunGroup = long.Parse(startAt.ToString("yyyyMMddhhmmss"));
                for (int i = AtlasController.Agents.Values.Count - 1; i >= 0; i--)
                {
                    AtlasController.Agents.Values.ElementAt(i).CurrentRun.StartTestAt = startAt;
                    AtlasController.Agents.Values.ElementAt(i).CurrentRun.RunGroup = RunGroup;
                    AtlasController.Agents.Values.ElementAt(i).CurrentRun.RunState = TestRunStatus.RunInitiated;
                }
            }
        }

        bool stopRequested = false;
        DateTime blankDateTime = new DateTime();
        private void UIUpdate()
        {
            try
            {
                bool isTestComplete = true;

                long TotalMessagesSent = 0;
                long TotalMessagesToSent = 0;
                //int OverallAverageResponse = 0;
                int OverallThroughput = 0;
                decimal OverallDataRate = 0;
                long OverallExceptions = 0;

                DateTime minStartTime = new DateTime();
                DateTime maxEndTime = new DateTime();

                for (int i = AtlasController.Agents.Values.Count - 1; i >= 0; i--)
                {
                    LoadAgent agent = AtlasController.Agents.Values.ElementAt(i);
                    TotalMessagesSent += agent.CurrentRun.MessagesSent;
                    OverallThroughput += agent.CurrentRun.MessagesPerMinute;
                    OverallDataRate += agent.CurrentRun.MBPerMinute;
                    OverallExceptions += agent.CurrentRun.ExceptionsRecieved;
                    TotalMessagesToSent += agent.CurrentRun.TotalMessages;
                    if ((minStartTime > agent.CurrentRun.TestStart) || (minStartTime == blankDateTime))
                        minStartTime = agent.CurrentRun.TestStart;
                    if (maxEndTime < agent.CurrentRun.TestEnd)
                        maxEndTime = agent.CurrentRun.TestEnd;

                    isTestComplete &= ((agent.CurrentRun.RunState == TestRunStatus.TestStopped) || (agent.CurrentRun.RunState == TestRunStatus.AgentShutDown) ||
                        (agent.CurrentRun.RunState == TestRunStatus.TestCompleted) || (agent.CurrentRun.RunState == TestRunStatus.Ready));
                }

                if (isTestComplete)
                {
                    cmdStartTest.Enabled = true;
                    cmdStopTest.Enabled = false;
                }
                else
                {
                    cmdStartTest.Enabled = false;
                    cmdStopTest.Enabled = !stopRequested;
                }

                for (int i = dgvAgents.Rows.Count - 1; i >= 0; i--)
                {
                    DataGridViewRow row = dgvAgents.Rows[i];
                    LoadAgent agent;
                    lock (AtlasController.Agents)
                    {
                        agent = AtlasController.Agents[row.Tag.ToString()];
                        agent.InGrid = true;
                    }

                    row.Cells[colDeviceSet.Index].Value = agent.DeviceSet;
                    row.Cells[colTotDevices.Index].Value = agent.CurrentRun.TotalDevices;
                    row.Cells[colTotMessgaes.Index].Value = agent.CurrentRun.TotalMessages;

                    row.Cells[colDeviceConnet.Index].Value = agent.CurrentRun.DeviceConnectTime;
                    row.Cells[colMessagesSent.Index].Value = agent.CurrentRun.MessagesSent;
                    row.Cells[colAvgResp.Index].Value = agent.CurrentRun.AverageResponseTimeInMS;
                    row.Cells[colPerc95Resp.Index].Value = agent.CurrentRun.Percentile95ResponseTimeInMS;
                    row.Cells[colThroughput.Index].Value = agent.CurrentRun.MessagesPerMinute;
                    row.Cells[colDataRate.Index].Value = agent.CurrentRun.MBPerMinute;
                    row.Cells[colExceptions.Index].Value = agent.CurrentRun.ExceptionsRecieved;

                    if (blankDateTime != agent.CurrentRun.TestStart)
                        row.Cells[colTestStart.Index].Value = agent.CurrentRun.TestStart;
                    else
                        row.Cells[colTestStart.Index].Value = string.Empty;

                    if (blankDateTime != agent.CurrentRun.TestEnd)
                        row.Cells[colTestEnd.Index].Value = agent.CurrentRun.TestEnd;
                    else
                        row.Cells[colTestEnd.Index].Value = string.Empty;

                    row.Cells[colPercTestCompletion.Index].Value = (agent.CurrentRun.ExceptionsRecieved + agent.CurrentRun.MessagesSent) * 100m / agent.CurrentRun.TotalMessages;

                    row.Cells[ColMemUsage.Index].Value = agent.MemoryUsage;
                    row.Cells[colCPUPerc.Index].Value = agent.CPUUsagePercentage;

                    row.Cells[colRunState.Index].Value = agent.CurrentRun.RunState;
                }


                for (int i = AtlasController.Agents.Values.Count - 1; i >= 0; i--)
                {
                    LoadAgent agent = AtlasController.Agents.Values.ElementAt(i);
                    if (!agent.InGrid)
                    {
                        int rowIndx = dgvAgents.Rows.Add(agent.AgentIP, agent.DeviceSet, agent.CurrentRun.TotalDevices,
                            agent.CurrentRun.TotalMessages, agent.CurrentRun.DeviceConnectTime, agent.CurrentRun.MessagesSent,
                            agent.CurrentRun.AverageResponseTimeInMS, agent.CurrentRun.Percentile95ResponseTimeInMS,
                            agent.CurrentRun.MessagesPerMinute, agent.CurrentRun.MBPerMinute, agent.CurrentRun.ExceptionsRecieved,
                            (blankDateTime != agent.CurrentRun.TestStart) ? agent.CurrentRun.TestStart.ToString("ddMMMyy HH:mm:ss") : string.Empty,
                            (blankDateTime != agent.CurrentRun.TestEnd) ? agent.CurrentRun.TestEnd.ToString("ddMMMyy HH:mm:ss") : string.Empty,
                            0, agent.MemoryUsage, agent.CPUUsagePercentage, agent.CurrentRun.RunState);
                        dgvAgents.Rows[rowIndx].Tag = agent.AgentIP;
                    }
                }

                TimeSpan elapsed = isTestComplete ? maxEndTime.Subtract(minStartTime) : DateTime.UtcNow.Subtract(minStartTime);
                cellTestCompletion.Value = (TotalMessagesToSent != 0 ? 100m * (OverallExceptions + TotalMessagesSent) / TotalMessagesToSent : 0).ToString("0.00") + "%";
                cellSuccessRate.Value = ((TotalMessagesSent + OverallExceptions) != 0 ? 100m * TotalMessagesSent / (TotalMessagesSent + OverallExceptions) : 0).ToString("0.00") + "%";
                cellMessageRate.Value = (TotalMessagesToSent != 0 ? 100m * TotalMessagesSent / TotalMessagesToSent : 0).ToString("0.00") + "%";
                cellElapsedTime.Value = minStartTime != blankDateTime ? elapsed.ToString("hh\\:mm\\:ss") : "00:00:00";
                cellRateDelay.Value = (minStartTime != blankDateTime ?  (100 * (TotalMessagesSent / ((elapsed.TotalMinutes / 600) * TotalMessagesToSent))) : 0).ToString("0.00") + "%";
                cellThroughput.Value = OverallThroughput.ToString("#,##0") + "msg(s)/min";
                cellDataRate.Value = OverallDataRate.ToString("0.000") + "MB/min";
                cellMessagesSent.Value = TotalMessagesSent.ToString("#,##0");
                cellMessagesToSent.Value = TotalMessagesToSent.ToString("#,##0");
                cellExceptions.Value = OverallExceptions.ToString("#,##0");

            }
            catch (Exception ex)
            {
                cellMessageTime.Value = DateTime.UtcNow.ToString("hh:mm:ss");
                cellMessageType.Value = ex.GetType().ToString();
                cellMessageText.Value = ex.Message;
            }
        }

        DataGridViewCell cellTestCompletion;
        DataGridViewCell cellSuccessRate;
        DataGridViewCell cellMessageRate;
        DataGridViewCell cellElapsedTime;
        DataGridViewCell cellRateDelay;
        DataGridViewCell cellThroughput;
        DataGridViewCell cellDataRate;
        DataGridViewCell cellMessagesSent;
        DataGridViewCell cellMessagesToSent;
        DataGridViewCell cellExceptions;
        DataGridViewCell cellMessageTime;
        DataGridViewCell cellMessageType;
        DataGridViewCell cellMessageText;

        TimeSyncServer timesync = new TimeSyncServer(new TcpTimeSyncBroadcaster(8463), 2000);
        
        IDisposable OwinWeb;
        private void frmMain_Load(object sender, EventArgs e)
        {
            //Setup - Open port 1234, 8463 in firewall and add urlacl
            //netsh http add urlacl url=http://+:1234/ user=Everyone

            string baseAddress = "http://+:1234/";
            OwinWeb = WebApp.Start<Startup>(url: baseAddress);
            timesync.Start();

            dgvSummary.Rows.Add("Overall Test Completion", "", "Success Rate", "", "Message Rate", "","Data Rate");
            dgvSummary.Rows.Add("Elapsed Time", "", "Test Rate", "", "Overall Throughput", "","Total Messages Sent");
            dgvSummary.Rows.Add("Total Exceptions", "", "Exception Message", "", "","", "Total Messages","");

            cellTestCompletion = dgvSummary[1, 0];
            cellSuccessRate = dgvSummary[3, 0];
            cellMessageRate = dgvSummary[5, 0];
            cellDataRate = dgvSummary[7, 0];
            cellElapsedTime = dgvSummary[1, 1];
            cellRateDelay = dgvSummary[3, 1];
            cellThroughput = dgvSummary[5, 1];
            cellMessagesSent = dgvSummary[7, 1];
            cellExceptions = dgvSummary[1, 2];
            cellMessageTime = dgvSummary[3, 2];
            cellMessageType= dgvSummary[4, 2];
            cellMessageText = dgvSummary[5, 2];
            cellMessagesToSent = dgvSummary[7, 2];
        }

        private void timUIUpdate_Tick(object sender, EventArgs e)
        {
            timUIUpdate.Enabled = false;
            UIUpdate();
            timUIUpdate.Enabled = true;
        }

        private void cmdStop_Click(object sender, EventArgs e)
        {
            try
            {
                stopRequested = true;
                lock (AtlasController.Agents)
                {
                    for (int i = AtlasController.Agents.Values.Count - 1; i >= 0; i--)
                    {
                        LoadAgent agent = AtlasController.Agents.Values.ElementAt(i);
                        agent.CurrentRun.RunState = TestRunStatus.StopRequested;
                    }
                }
                cmdStopTest.Enabled = false;
            }
            catch (Exception ex)
            {
                cellMessageTime.Value = DateTime.UtcNow.ToString("hh:mm:ss");
                cellMessageType.Value = ex.GetType().ToString();
                cellMessageText.Value = ex.Message;
            }
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            timesync.Stop();
        }
    }
}
