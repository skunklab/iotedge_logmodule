﻿using Atlas.Common;
using System;
using System.Collections.Generic;
using System.Web.Http;

namespace Atlas.IoT
{
    public class AtlasController:ApiController
    {
        public static Dictionary<string, LoadAgent> Agents = new Dictionary<string, LoadAgent>();

        public void Post(LoadAgent agentInfo)
        {
            if (agentInfo != null)
            {
                try
                {
                    lock (Agents)
                    {
                        if (Agents.ContainsKey(agentInfo.AgentIP))
                        {
                            LoadAgent agnt = Agents[agentInfo.AgentIP];
                            agentInfo.InGrid = agnt.InGrid;
                            Agents[agentInfo.AgentIP] = agentInfo;
                            agnt = null;
                        }
                        else
                            Agents.Add(agentInfo.AgentIP, agentInfo);
                    }
                }
                catch (Exception)
                {
                }

                agentInfo = null;
            }
        }

        public LoadAgent Get(string AgentName)
        {
            try
            {
                lock (Agents)
                {
                    if (Agents.ContainsKey(AgentName))
                        return Agents[AgentName];
                    else
                        return null;
                }
            }
            catch (Exception) { }
            return null;
        }
    }
}
