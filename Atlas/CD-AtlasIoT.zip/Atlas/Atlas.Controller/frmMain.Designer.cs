﻿namespace Atlas.IoT
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.cmdStartTest = new System.Windows.Forms.Button();
            this.dgvAgents = new System.Windows.Forms.DataGridView();
            this.colAgent = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDeviceSet = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTotDevices = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTotMessgaes = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDeviceConnet = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMessagesSent = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colAvgResp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPerc95Resp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colThroughput = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDataRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colExceptions = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTestStart = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTestEnd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPercTestCompletion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColMemUsage = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCPUPerc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRunState = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.timUIUpdate = new System.Windows.Forms.Timer(this.components);
            this.cmdStopTest = new System.Windows.Forms.Button();
            this.dgvSummary = new System.Windows.Forms.DataGridView();
            this.colOne = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSeven = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEight = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTwo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colThree = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFour = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colFive = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSix = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAgents)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSummary)).BeginInit();
            this.SuspendLayout();
            // 
            // cmdStartTest
            // 
            this.cmdStartTest.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdStartTest.Location = new System.Drawing.Point(1299, 12);
            this.cmdStartTest.Name = "cmdStartTest";
            this.cmdStartTest.Size = new System.Drawing.Size(131, 26);
            this.cmdStartTest.TabIndex = 0;
            this.cmdStartTest.Text = "Start Test";
            this.cmdStartTest.UseVisualStyleBackColor = true;
            this.cmdStartTest.Click += new System.EventHandler(this.cmdStartTest_Click);
            // 
            // dgvAgents
            // 
            this.dgvAgents.AllowUserToAddRows = false;
            this.dgvAgents.AllowUserToDeleteRows = false;
            this.dgvAgents.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvAgents.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvAgents.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAgents.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colAgent,
            this.colDeviceSet,
            this.colTotDevices,
            this.colTotMessgaes,
            this.colDeviceConnet,
            this.colMessagesSent,
            this.colAvgResp,
            this.colPerc95Resp,
            this.colThroughput,
            this.colDataRate,
            this.colExceptions,
            this.colTestStart,
            this.colTestEnd,
            this.colPercTestCompletion,
            this.ColMemUsage,
            this.colCPUPerc,
            this.colRunState});
            this.dgvAgents.Location = new System.Drawing.Point(12, 102);
            this.dgvAgents.Margin = new System.Windows.Forms.Padding(0);
            this.dgvAgents.Name = "dgvAgents";
            this.dgvAgents.ReadOnly = true;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvAgents.RowHeadersDefaultCellStyle = dataGridViewCellStyle15;
            this.dgvAgents.RowHeadersVisible = false;
            this.dgvAgents.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvAgents.Size = new System.Drawing.Size(1418, 207);
            this.dgvAgents.TabIndex = 1;
            // 
            // colAgent
            // 
            this.colAgent.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            this.colAgent.DataPropertyName = "AgentIP";
            this.colAgent.HeaderText = "Agent";
            this.colAgent.MinimumWidth = 50;
            this.colAgent.Name = "colAgent";
            this.colAgent.ReadOnly = true;
            this.colAgent.Width = 50;
            // 
            // colDeviceSet
            // 
            this.colDeviceSet.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            this.colDeviceSet.DataPropertyName = "DeviceSet";
            this.colDeviceSet.HeaderText = "Device Set";
            this.colDeviceSet.MinimumWidth = 75;
            this.colDeviceSet.Name = "colDeviceSet";
            this.colDeviceSet.ReadOnly = true;
            this.colDeviceSet.Width = 75;
            // 
            // colTotDevices
            // 
            this.colTotDevices.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            this.colTotDevices.DataPropertyName = "TotalDevices";
            dataGridViewCellStyle2.Format = "#,###";
            this.colTotDevices.DefaultCellStyle = dataGridViewCellStyle2;
            this.colTotDevices.HeaderText = "Devices";
            this.colTotDevices.MinimumWidth = 50;
            this.colTotDevices.Name = "colTotDevices";
            this.colTotDevices.ReadOnly = true;
            this.colTotDevices.Width = 50;
            // 
            // colTotMessgaes
            // 
            this.colTotMessgaes.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            this.colTotMessgaes.DataPropertyName = "TotalMessages";
            dataGridViewCellStyle3.Format = "#,###";
            this.colTotMessgaes.DefaultCellStyle = dataGridViewCellStyle3;
            this.colTotMessgaes.HeaderText = "Total Messages";
            this.colTotMessgaes.MinimumWidth = 70;
            this.colTotMessgaes.Name = "colTotMessgaes";
            this.colTotMessgaes.ReadOnly = true;
            this.colTotMessgaes.Width = 70;
            // 
            // colDeviceConnet
            // 
            this.colDeviceConnet.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            this.colDeviceConnet.DataPropertyName = "DeviceConnectTime";
            dataGridViewCellStyle4.Format = "#,###";
            this.colDeviceConnet.DefaultCellStyle = dataGridViewCellStyle4;
            this.colDeviceConnet.HeaderText = "Device Connect (ms)";
            this.colDeviceConnet.MinimumWidth = 70;
            this.colDeviceConnet.Name = "colDeviceConnet";
            this.colDeviceConnet.ReadOnly = true;
            this.colDeviceConnet.Width = 70;
            // 
            // colMessagesSent
            // 
            this.colMessagesSent.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            this.colMessagesSent.DataPropertyName = "MessagesSent";
            dataGridViewCellStyle5.Format = "#,###";
            this.colMessagesSent.DefaultCellStyle = dataGridViewCellStyle5;
            this.colMessagesSent.HeaderText = "Messages Sent";
            this.colMessagesSent.MinimumWidth = 75;
            this.colMessagesSent.Name = "colMessagesSent";
            this.colMessagesSent.ReadOnly = true;
            this.colMessagesSent.Width = 75;
            // 
            // colAvgResp
            // 
            this.colAvgResp.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            this.colAvgResp.DataPropertyName = "AverageResponseTime";
            dataGridViewCellStyle6.Format = "#,###";
            this.colAvgResp.DefaultCellStyle = dataGridViewCellStyle6;
            this.colAvgResp.HeaderText = "Avg. Response (ms)";
            this.colAvgResp.MinimumWidth = 100;
            this.colAvgResp.Name = "colAvgResp";
            this.colAvgResp.ReadOnly = true;
            // 
            // colPerc95Resp
            // 
            this.colPerc95Resp.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            this.colPerc95Resp.DataPropertyName = "Percentile95ResponseTimeInMS";
            dataGridViewCellStyle7.Format = "#,###";
            this.colPerc95Resp.DefaultCellStyle = dataGridViewCellStyle7;
            this.colPerc95Resp.HeaderText = "95% Response (ms)";
            this.colPerc95Resp.MinimumWidth = 100;
            this.colPerc95Resp.Name = "colPerc95Resp";
            this.colPerc95Resp.ReadOnly = true;
            // 
            // colThroughput
            // 
            this.colThroughput.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            this.colThroughput.DataPropertyName = "MessagesPerMinute";
            dataGridViewCellStyle8.Format = "#,###";
            this.colThroughput.DefaultCellStyle = dataGridViewCellStyle8;
            this.colThroughput.HeaderText = "Throughput (msg/min)";
            this.colThroughput.MinimumWidth = 100;
            this.colThroughput.Name = "colThroughput";
            this.colThroughput.ReadOnly = true;
            // 
            // colDataRate
            // 
            this.colDataRate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            dataGridViewCellStyle9.Format = "0.000";
            this.colDataRate.DefaultCellStyle = dataGridViewCellStyle9;
            this.colDataRate.HeaderText = "Data Rate (MB/min)";
            this.colDataRate.MinimumWidth = 100;
            this.colDataRate.Name = "colDataRate";
            this.colDataRate.ReadOnly = true;
            // 
            // colExceptions
            // 
            this.colExceptions.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            this.colExceptions.DataPropertyName = "ExceptionsRecieved";
            dataGridViewCellStyle10.Format = "#,###";
            this.colExceptions.DefaultCellStyle = dataGridViewCellStyle10;
            this.colExceptions.HeaderText = "Exceptions";
            this.colExceptions.MinimumWidth = 70;
            this.colExceptions.Name = "colExceptions";
            this.colExceptions.ReadOnly = true;
            this.colExceptions.Width = 70;
            // 
            // colTestStart
            // 
            this.colTestStart.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            this.colTestStart.DataPropertyName = "TestStart";
            dataGridViewCellStyle11.Format = "ddMMMyyyy HH:mm:ss";
            this.colTestStart.DefaultCellStyle = dataGridViewCellStyle11;
            this.colTestStart.HeaderText = "Test Start";
            this.colTestStart.MinimumWidth = 75;
            this.colTestStart.Name = "colTestStart";
            this.colTestStart.ReadOnly = true;
            this.colTestStart.Width = 75;
            // 
            // colTestEnd
            // 
            this.colTestEnd.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            this.colTestEnd.DataPropertyName = "TestEnd";
            dataGridViewCellStyle12.Format = "ddMMMyyyy HH:mm:ss";
            this.colTestEnd.DefaultCellStyle = dataGridViewCellStyle12;
            this.colTestEnd.HeaderText = "Test End";
            this.colTestEnd.MinimumWidth = 75;
            this.colTestEnd.Name = "colTestEnd";
            this.colTestEnd.ReadOnly = true;
            this.colTestEnd.Width = 75;
            // 
            // colPercTestCompletion
            // 
            this.colPercTestCompletion.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            dataGridViewCellStyle13.Format = "0.00";
            this.colPercTestCompletion.DefaultCellStyle = dataGridViewCellStyle13;
            this.colPercTestCompletion.HeaderText = "Completion (%)";
            this.colPercTestCompletion.MinimumWidth = 70;
            this.colPercTestCompletion.Name = "colPercTestCompletion";
            this.colPercTestCompletion.ReadOnly = true;
            this.colPercTestCompletion.Width = 70;
            // 
            // ColMemUsage
            // 
            this.ColMemUsage.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            dataGridViewCellStyle14.Format = "#,###";
            this.ColMemUsage.DefaultCellStyle = dataGridViewCellStyle14;
            this.ColMemUsage.HeaderText = "Memory (MB)";
            this.ColMemUsage.MinimumWidth = 60;
            this.ColMemUsage.Name = "ColMemUsage";
            this.ColMemUsage.ReadOnly = true;
            this.ColMemUsage.Width = 60;
            // 
            // colCPUPerc
            // 
            this.colCPUPerc.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            this.colCPUPerc.HeaderText = "CPU (%)";
            this.colCPUPerc.MinimumWidth = 60;
            this.colCPUPerc.Name = "colCPUPerc";
            this.colCPUPerc.ReadOnly = true;
            this.colCPUPerc.Width = 60;
            // 
            // colRunState
            // 
            this.colRunState.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colRunState.DataPropertyName = "RunState";
            this.colRunState.HeaderText = "Run State";
            this.colRunState.MinimumWidth = 100;
            this.colRunState.Name = "colRunState";
            this.colRunState.ReadOnly = true;
            // 
            // timUIUpdate
            // 
            this.timUIUpdate.Enabled = true;
            this.timUIUpdate.Interval = 1000;
            this.timUIUpdate.Tick += new System.EventHandler(this.timUIUpdate_Tick);
            // 
            // cmdStopTest
            // 
            this.cmdStopTest.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdStopTest.Enabled = false;
            this.cmdStopTest.Location = new System.Drawing.Point(1299, 54);
            this.cmdStopTest.Name = "cmdStopTest";
            this.cmdStopTest.Size = new System.Drawing.Size(131, 26);
            this.cmdStopTest.TabIndex = 3;
            this.cmdStopTest.Text = "Abort Test";
            this.cmdStopTest.UseVisualStyleBackColor = true;
            this.cmdStopTest.Click += new System.EventHandler(this.cmdStop_Click);
            // 
            // dgvSummary
            // 
            this.dgvSummary.AllowUserToAddRows = false;
            this.dgvSummary.AllowUserToDeleteRows = false;
            this.dgvSummary.AllowUserToResizeColumns = false;
            this.dgvSummary.AllowUserToResizeRows = false;
            this.dgvSummary.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvSummary.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSummary.ColumnHeadersVisible = false;
            this.dgvSummary.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colOne,
            this.colSeven,
            this.colEight,
            this.colTwo,
            this.colThree,
            this.colFour,
            this.colFive,
            this.colSix});
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle20.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle20.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvSummary.DefaultCellStyle = dataGridViewCellStyle20;
            this.dgvSummary.Location = new System.Drawing.Point(12, 12);
            this.dgvSummary.Name = "dgvSummary";
            this.dgvSummary.ReadOnly = true;
            this.dgvSummary.RowHeadersVisible = false;
            this.dgvSummary.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvSummary.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dgvSummary.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvSummary.Size = new System.Drawing.Size(1270, 69);
            this.dgvSummary.TabIndex = 4;
            // 
            // colOne
            // 
            this.colOne.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.colOne.DefaultCellStyle = dataGridViewCellStyle16;
            this.colOne.HeaderText = "";
            this.colOne.Name = "colOne";
            this.colOne.ReadOnly = true;
            // 
            // colSeven
            // 
            this.colSeven.HeaderText = "";
            this.colSeven.Name = "colSeven";
            this.colSeven.ReadOnly = true;
            // 
            // colEight
            // 
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.colEight.DefaultCellStyle = dataGridViewCellStyle17;
            this.colEight.HeaderText = "";
            this.colEight.Name = "colEight";
            this.colEight.ReadOnly = true;
            // 
            // colTwo
            // 
            this.colTwo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colTwo.HeaderText = "";
            this.colTwo.Name = "colTwo";
            this.colTwo.ReadOnly = true;
            // 
            // colThree
            // 
            this.colThree.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.colThree.DefaultCellStyle = dataGridViewCellStyle18;
            this.colThree.HeaderText = "";
            this.colThree.Name = "colThree";
            this.colThree.ReadOnly = true;
            // 
            // colFour
            // 
            this.colFour.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colFour.HeaderText = "";
            this.colFour.Name = "colFour";
            this.colFour.ReadOnly = true;
            // 
            // colFive
            // 
            this.colFive.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.colFive.DefaultCellStyle = dataGridViewCellStyle19;
            this.colFive.HeaderText = "";
            this.colFive.Name = "colFive";
            this.colFive.ReadOnly = true;
            // 
            // colSix
            // 
            this.colSix.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colSix.HeaderText = "";
            this.colSix.Name = "colSix";
            this.colSix.ReadOnly = true;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1442, 318);
            this.Controls.Add(this.dgvSummary);
            this.Controls.Add(this.cmdStopTest);
            this.Controls.Add(this.dgvAgents);
            this.Controls.Add(this.cmdStartTest);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmMain";
            this.Text = "Atlas Load Test Controller";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.Load += new System.EventHandler(this.frmMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAgents)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSummary)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button cmdStartTest;
        private System.Windows.Forms.DataGridView dgvAgents;
        private System.Windows.Forms.Timer timUIUpdate;
        private System.Windows.Forms.Button cmdStopTest;
        private System.Windows.Forms.DataGridViewTextBoxColumn colAgent;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDeviceSet;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTotDevices;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTotMessgaes;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDeviceConnet;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMessagesSent;
        private System.Windows.Forms.DataGridViewTextBoxColumn colAvgResp;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPerc95Resp;
        private System.Windows.Forms.DataGridViewTextBoxColumn colThroughput;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDataRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn colExceptions;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTestStart;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTestEnd;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPercTestCompletion;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColMemUsage;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCPUPerc;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRunState;
        private System.Windows.Forms.DataGridView dgvSummary;
        private System.Windows.Forms.DataGridViewTextBoxColumn colOne;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSeven;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEight;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTwo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colThree;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFour;
        private System.Windows.Forms.DataGridViewTextBoxColumn colFive;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSix;
    }
}

