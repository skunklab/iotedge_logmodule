﻿using System;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;
using System.IO;

namespace Atlas.IoT
{
    class Program
    {
        static List<IoTDevice> IoTDevices = new List<IoTDevice>();

        static string GetJSONKeyValue(string key, string json)
        {
            key = "\"" + key + "\":\"";
            int ind = json.IndexOf(key) + key.Length;
            return json.Substring(ind, json.IndexOf("\",", ind) - ind);
        }

        static void Main(string[] args)
        {
            if (args.Length > 0)
            {
                switch (args[0])
                {
                    case "Import":
                        IoTDevice.ImportDevices().Wait();
                        Console.WriteLine(" Import Initiated!");
                        break;
                    case "Export":
                        IoTDevice.ExportAllDevices().Wait();
                        Console.WriteLine(" Export Initiated!");
                        break;
                    case "Get":
                        int MaxBound = int.Parse(args[1]);
                        GetDevicesAsync(MaxBound).Wait();
                        TextWriter writer = File.CreateText("TCUs" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".csv");
                        writer.WriteLine("DeviceId,Vin,Mileage,NoOfMessages,Key");
                        int devicesAdded = 0;
                        foreach (IoTDevice dev in IoTDevices)
                            if (dev.Write(writer, true))
                                devicesAdded++;
                        writer.Close();

                        Console.WriteLine("Saved {0} devices. ...", devicesAdded);
                        break;
                    case "Add":
                        MaxBound = int.Parse(args[1]);
                        bool[] iotdevindex = new bool[MaxBound + 1];

                        GetDevicesAsync(MaxBound).Wait();

                        foreach (IoTDevice iotdev in IoTDevices)
                            iotdevindex[int.Parse(iotdev.DeviceId)] = true;

                        Console.WriteLine("Found {0} devices.", IoTDevices.Count);

                        for (int j = 0; j < MaxBound / 100; j++)
                        {
                            List<IoTDevice> NewIoTDevices = new List<IoTDevice>();
                            for (int i = 100 * j + 1; i <= 100 + (100 * j); i++)
                                if (!iotdevindex[i])
                                    NewIoTDevices.Add(new IoTDevice(i.ToString()));

                            Console.WriteLine("Trying to add {0} to {1} - {2} devices.", 100 * j + 1, 100 + (100 * j), NewIoTDevices.Count);
                            AddAllDevicesAsync(NewIoTDevices).Wait();
                            Console.WriteLine("Added {0} devices.", NewIoTDevices.Count);
                        }

                        break;
                    case "Parse":
                        string line;
                        TextReader reader = File.OpenText(args[1]);
                        Random rndm = new Random();
                        writer = File.CreateText("TCUs" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".csv");
                        writer.WriteLine("DeviceId,IoTHub,NoofMessages,StartDelay,MessageDelay,DeviceKey,DeviceSet,DeviceConfig");

                        while ((line = reader.ReadLine()) != null)
                        {
                            string deviceid = GetJSONKeyValue("id", line);
                            string devicekey = GetJSONKeyValue("primaryKey", line);

                            writer.WriteLine(deviceid + "," + args[3] + ",2," + rndm.Next(30).ToString() + ",10," + devicekey + "," + args[2] + ",-");
                        }

                        reader.Close();
                        writer.Close();

                        Console.WriteLine("Conversion Completed.");
                        break;
                    case "Generate":
                        int MinBound = int.Parse(args[1]);
                        MaxBound = int.Parse(args[2]);
                        string IotdevicePattern = "{\"id\":\"%deviceid%\",\"eTag\":\"MA==\",\"status\":\"enabled\",\"authentication\":{\"symmetricKey\":{\"primaryKey\":\"T3Blbm1hdGljc0RldmljZUtleQ==\",\"secondaryKey\":\"T3Blbm1hdGljc0RldmljZUtleQ==\"},\"x509Thumbprint\":{\"primaryThumbprint\":null,\"secondaryThumbprint\":null}},\"twinETag\":\"AAAAAAAAAAE=\",\"tags\":{},\"properties\":{\"desired\":{\"$metadata\":{\"$lastUpdated\":\"2017-04-04T12:00:00.000000Z\"},\"$version\":1},\"reported\":{\"$metadata\":{\"$lastUpdated\":\"2017-04-04T12:00:00.000000Z\"},\"$version\":1}}}";
                        writer = File.CreateText("NewIotDevices" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".json");
                        for (int i = MinBound; i <= MaxBound; i++)
                            writer.WriteLine(IotdevicePattern.Replace("%deviceid%", i.ToString())); //"A" + i.ToString("0000000")));
                        writer.Close();
                        Console.WriteLine("Generation Completed.");

                        break;
                    case "Stats":
                        IoTDevice.PrintIoTHubStats().Wait();
                        break;
                    case "JobStats":
                        IoTDevice.PrintIoTHubJobStats(args[1]).Wait();
                        break;
                }
            }
            else
            {
                Console.WriteLine("Usage:");
                Console.WriteLine("AtlasDeviceRegistrar.exe Add|Import|Export|Get|Parse|Generate|Stats|JobStats\n{Add->MaxBound}|{Parse->JsonFile DeviceSet IoTHub}|{Get->MaxBound}|{Generate->MinBound MaxBound}|{JobStats->JobId}");
            }

            Console.WriteLine("Press Any key to exit!");
            Console.ReadLine();
        }

        private async static Task GetDevicesAsync(int MaxBound)
        {
            IoTDevices = await IoTDevice.GetDevices(MaxBound);
        }
        private static Task AddAllDevicesAsync(List<IoTDevice> devicesToAdd)
        { return Task.WhenAll(devicesToAdd.Select(k => k.AddDeviceAsync())); }

    }
}