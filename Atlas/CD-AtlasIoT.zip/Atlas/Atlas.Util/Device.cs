﻿using Microsoft.Azure.Devices;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atlas.IoT
{
    class IoTDevice
    {
        static string connectionString = ConfigurationManager.ConnectionStrings["IoTHub"].ConnectionString;
        static RegistryManager registryManager = RegistryManager.CreateFromConnectionString(connectionString);
        static string blobConnection = ConfigurationManager.ConnectionStrings["DataStore"].ConnectionString;
        static string blobcontURI = GetBlobSasUri(blobConnection);

        public string DeviceId { get; set; }
        public string DeviceKey { get; set; }

        public IoTDevice(string deviceId)
        {
            DeviceId = deviceId;
        }
        public IoTDevice(string deviceId, string deviceKey)
        {
            DeviceId = deviceId;
            DeviceKey = deviceKey;
            IsNewlyRegistered = true;
        }
        public bool IsNewlyRegistered { get; private set; } = false;

        public async Task<bool> WriteAsync(TextWriter writer)
        {
            if (IsNewlyRegistered)
            {
                await writer.WriteLineAsync(DeviceId + "," + DeviceId + ",1000,10," + DeviceKey);
                IsNewlyRegistered = false;
                return true;
            }
            return false;
        }

        public bool Write(TextWriter writer, bool All)
        {
            if (IsNewlyRegistered || All)
            {
                writer.WriteLine(DeviceId + "," + DeviceId + ",1000,10," + DeviceKey);
                IsNewlyRegistered = false;
                return true;
            }
            return false;
        }

        public static async Task<List<IoTDevice>> GetDevices(int MaxBound)
        {
            IEnumerable<Device> devices = await registryManager.GetDevicesAsync(MaxBound);

            List<IoTDevice> iotdevices = new List<IoTDevice>();
            foreach(Device dev in devices)
            {
                iotdevices.Add(new IoTDevice(dev.Id, dev.Authentication.SymmetricKey.PrimaryKey));
            }

            return iotdevices;
        }

        static string GetBlobSasUri(string StorageConnectionString)
        {
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(StorageConnectionString);

            //Create the blob client object.
            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();


            //Get a reference to a blob within the container.
            CloudBlobContainer container = blobClient.GetContainerReference("atlas");
            container.CreateIfNotExists();
            //Set the expiry time and permissions for the blob.
            //In this case the start time is specified as a few minutes in the past, to mitigate clock skew.
            //The shared access signature will be valid immediately.
            SharedAccessBlobPolicy sasConstraints = new SharedAccessBlobPolicy();
            sasConstraints.SharedAccessStartTime = DateTime.UtcNow.AddMinutes(-5);
            sasConstraints.SharedAccessExpiryTime = DateTime.UtcNow.AddHours(24);
            sasConstraints.Permissions = SharedAccessBlobPermissions.Read | SharedAccessBlobPermissions.Write | SharedAccessBlobPermissions.Delete;

            //Generate the shared access signature on the blob, setting the constraints directly on the signature.
            string sasContainerToken = container.GetSharedAccessSignature(sasConstraints);

            //Return the URI string for the container, including the SAS token.
            return container.Uri + sasContainerToken;
        }
        public static async Task PrintIoTHubStats()
        {
            RegistryStatistics regStat = await registryManager.GetRegistryStatisticsAsync();
            Console.WriteLine("Devices Enabled={0}; Disabled={1}; Total={2}",
            regStat.EnabledDeviceCount, regStat.DisabledDeviceCount, regStat.TotalDeviceCount);
        }

        public static async Task PrintIoTHubJobStats(string JobId)
        {
            JobProperties jobStat = await registryManager.GetJobAsync(JobId);
            Console.WriteLine("Job Status={0}; Type={1}; Progress={2}%\nStart={3}; End={4};\nExcludeKeys={5}; Reason={6}",
            jobStat.Status, jobStat.Type, jobStat.Progress, jobStat.StartTimeUtc, jobStat.EndTimeUtc,
            jobStat.ExcludeKeysInExport, jobStat.FailureReason);
        }

        public static async Task ExportAllDevices()
        {
            JobProperties job = await registryManager.ExportDevicesAsync(blobcontURI, false);
            Console.Write("JobId = {0}", job.JobId);
        }

        public static async Task ImportDevices()
        {
            JobProperties job = await registryManager.ImportDevicesAsync(blobcontURI, blobcontURI, "NewIotDevices.json");
            Console.Write("JobId = {0}", job.JobId);
        }

        public async Task AddDeviceAsync()
        {
            Device device;
            try
            {
                device = await registryManager.AddDeviceAsync(new Device(DeviceId));
                DeviceKey = device.Authentication.SymmetricKey.PrimaryKey;
                IsNewlyRegistered = true;
            }
            catch (Exception)
            {
            }
        }
    }
}
