We recommend running this sample in elevated mode in Visual studio.
