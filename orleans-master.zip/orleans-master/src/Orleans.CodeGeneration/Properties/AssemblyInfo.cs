﻿using System.Runtime.CompilerServices;
using Orleans.CodeGeneration;

[assembly: InternalsVisibleTo("Orleans.Runtime")]

[assembly: SkipCodeGeneration]
