using System;

namespace Orleans.Runtime
{
    [Serializable]
    public abstract class PlacementStrategy
    {
    }
}
