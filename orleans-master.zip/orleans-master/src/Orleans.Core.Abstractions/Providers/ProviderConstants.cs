﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Orleans.Providers
{
    public static class ProviderConstants
    {
        public const string DEFAULT_STORAGE_PROVIDER_NAME = "Default";

        public const string DEFAULT_LOG_CONSISTENCY_PROVIDER_NAME = "Default";
    }
}
