namespace Orleans.Services
{
    public interface IGrainService : ISystemTarget
    {
    }
}